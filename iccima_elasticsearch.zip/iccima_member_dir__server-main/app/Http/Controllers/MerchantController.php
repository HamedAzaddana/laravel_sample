<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\MerchantUser as MerchantUserModel;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class MerchantController extends Controller
{
    public function homeAllView()
    {
        $route_ws_search_index = route("ws.search.index");
        $route_ws_search_get_fv = route("ws.search.get_filters_var");

        return Inertia::render('Index', [
            'ws_s_route' => $route_ws_search_index,
            'ws_search_get_fv' => $route_ws_search_get_fv,
        ]);
    }
    public function singleView($hash_id,$slug='')
    {
        $route_ws_get_single = route("ws.search.single");
        $route_404_page = route("errors.404.view");
        $route_ws_saveVals = route("ws.search.saveVals");
        $route_ws_delBrImg = route("ws.search.delBrImg");

        return Inertia::render('SingleMerchant', [
            'hid' => $hash_id,
            'slug' => $slug,
            'route_ws_get_single' => $route_ws_get_single,
            'route_404_page' => $route_404_page,
            'route_ws_saveVals' => $route_ws_saveVals,
            'route_ws_delBrImg' => $route_ws_delBrImg,
        ]);
    }
}
