<?php

/*
|--------------------------------------------------------------------------
| Ship Helpers
|--------------------------------------------------------------------------
|
| Write only general helper functions here.
| Container specific helper functions should go into their own related Containers.
| All files under app/{section_name}/{container_name}/Helpers/ folder will be autoloaded by Apiato.
|
*/

use \Illuminate\Support\Carbon;


if (!function_exists('random_number')) {
    function random_number($min = 1000, $max = 9999)
    {
        return app('util')->getRandomNumber($min, $max);
    }
}

if (!function_exists('send_verification_code_by_sms')) {
    function send_verification_code_by_sms($phone, $code)
    {
        app('util')->sendVerificationCodeBySms($phone, $code);
    }
}

if (!function_exists('send_message_by_sms')) {
    function send_message_by_sms($phone, $meesage)
    {
        app('util')->sendMessageBySms($phone, $meesage);
    }
}

if (!function_exists('is_verification_code_true')) {
    function is_verification_code_true($phone, $code)
    {
        return app('util')->isVerificationCodeTrue($phone, $code);
    }
}

if (!function_exists('file_store')) {
    function file_store($file, $path): string
    {
        return app('util')->fileStore($file, $path);
    }
}

if (!function_exists('file_delete')) {
    function file_delete($path): bool
    {
        return app('util')->fileDelete($path);
    }
}

if (!function_exists('timestamp')) {
    function timestamp(): int
    {
        $now = Carbon::now()->getTimestampMs();
        return $now;
    }
}
if (!function_exists('timestamp_to_gregorian_date')) {
    function timestamp_to_gregorian_date($timestamp, $timezone = 'Asia/Tehran'): string|null
    {
        return app('util')->timestampToDate($timestamp, $timezone);
    }
}
if (!function_exists('timestamp_to_jalali_date')) {
    function timestamp_to_jalali_date($timestamp, $timezone = 'Asia/Tehran'): string|null
    {
        return date_to_jalali(timestamp_to_gregorian_date($timestamp, $timezone), true);
    }
}
if (!function_exists('timestamp_to_date')) {
    function timestamp_to_date($timestamp, $timezone = 'Asia/Tehran', $calendarType = \App\Enums\CalendarTypeEnum::jalali): string|null
    {
        if ($calendarType == \App\Enums\CalendarTypeEnum::jalali) {
            return timestamp_to_jalali_date($timestamp, $timezone);
        } else {
            return timestamp_to_gregorian_date($timestamp, $timezone);
        }
    }
}

if (!function_exists('date_to_jalali')) {
    function date_to_jalali($date, $showTime = false, $sep = '-'): string
    {
        return app('util')->toJalali($date, $showTime, $sep);
    }
}

if (!function_exists('date_to_gregorian')) {
    function date_to_gregorian($date, $showTime = false, $sep = '-'): string
    {
        return app('util')->toGregorian($date, $showTime, $sep);
    }
}

if (!function_exists('upload_path')) {
    function upload_path(string $path): string
    {
        return app('util')->getUploadPath($path);
    }
}

if (!function_exists('text_normalization')) {
    function text_normalization($text): string
    {
        return app('util')->textNormalization($text);
    }
}

if (!function_exists('text_simplization')) {
    function text_simplization($text): string
    {
        return app('util')->textSimplization($text);
    }
}

if (!function_exists('to_en_number')) {
    function to_en_number($text)
    {
        return app('util')->convertToEn($text);
    }
}

if (!function_exists('phone_normalization')) {
    function phone_normalization($phone): string
    {
        if (strpos($phone, '98') !== 0) {
            if (strpos($phone, '9') !== 0) {
                if (strpos($phone, '0') === 0) {
                    $phone = '98' . substr($phone, 1);
                }
            } else {
                $phone .= '98';
            }
        }
        return text_simplization(to_en_number($phone));
    }
}
if (!function_exists('date_jalali_to_timestamp')) {
    function date_jalali_to_timestamp($date, $timezone = 'UTC'): int|null
    {
        return date_gregorian_to_timestamp(date_to_gregorian($date, true), $timezone);
    }
}
if (!function_exists('convertToEn')) {
    function convertToEn($string)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١', '٠'];

        $num = range(0, 9);
        $convertedPersianNums = str_replace($persian, $num, $string);
        $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);

        return $englishNumbersOnly;
    }
}
if (!function_exists('twoNum')) {
    function twoNum($string)
    {
        if (strlen($string) < 2)
            return '0' . $string;
        else
            return $string;
    }
}

if (!function_exists('date_to_gregorian')) {
    function date_to_gregorian($date, $showTime = true, $sep = '-'): string
    {
        if (!empty(trim($date))) {
            try {
                $date = convertToEn($date);
                $time = '23:59:59';
                $date = explode(' ', $date);
                if (count($date) > 1) {
                    $time = $date[1];
                }
                $date = $date[0];
                if (strpos($date, '/') !== false) {
                    $date = explode('/', $date);
                    $date = \Morilog\Jalali\CalendarUtils::toGregorian($date[0], twoNum($date[1]), twoNum($date[2]));
                } else {
                    $date = explode('-', $date);
                    $date = \Morilog\Jalali\CalendarUtils::toGregorian($date[0], twoNum($date[1]), twoNum($date[2]));
                }
                if ($showTime && $time != '') {
                    return $date[0] . $sep . twoNum($date[1]) . $sep . twoNum($date[2]) . ' ' . $time;
                } else {
                    return $date[0] . $sep . twoNum($date[1]) . $sep . twoNum($date[2]);
                }
            } catch (\Exception $e) {
                return '';
            }
        } else {
            return '';
        }
    }
}
if (!function_exists('date_gregorian_to_timestamp')) {
    function date_gregorian_to_timestamp($value, $timezone = 'UTC'): int|null
    {
        if (strlen($value) > 19)
            $value = substr($value, 0, 19);
        $value = Carbon::parse($value, $timezone)->getTimestampMs();
        return $value;
    }
}
if (!function_exists('distance_between_lat_lon')) {
    function distance_between_lat_lon($lat1, $lon1, $lat2, $lon2)
    {
        if (($lat1 == $lat2) && ($lon1 == $lon2)) {
            return 0;
        } else {
            $theta = $lon1 - $lon2;
            $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
            $dist = acos($dist);
            $dist = rad2deg($dist);
            $miles = $dist * 60 * 1.1515;
            return ($miles * 1.609344) * 1000;
        }
    }
}
