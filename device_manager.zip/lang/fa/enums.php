<?php declare(strict_types=1);


return [

    \App\Enums\FeatureEnum::class => [
        \App\Enums\FeatureEnum::i0 => 'Wifi',
        \App\Enums\FeatureEnum::i1 => 'ResetFactory',
        \App\Enums\FeatureEnum::i2 => 'InstallApp',
        \App\Enums\FeatureEnum::i3 => 'Nfc',
        \App\Enums\FeatureEnum::i4 => 'OutgoingCall',
        \App\Enums\FeatureEnum::i5 => 'Sms',
        \App\Enums\FeatureEnum::i6 => 'Microphone',
        \App\Enums\FeatureEnum::i7 => 'UsbFileTransfer',
        \App\Enums\FeatureEnum::i8 => 'Camera',
        \App\Enums\FeatureEnum::i9 => 'ScreenCapture',
        \App\Enums\FeatureEnum::l1 => 'Hotspot',
        \App\Enums\FeatureEnum::l2 => 'Network',
        \App\Enums\FeatureEnum::l3 => 'Bluetooth',
        \App\Enums\FeatureEnum::l4 => 'DeviceLocation',
        \App\Enums\FeatureEnum::l5 => 'Vpn',
        \App\Enums\FeatureEnum::l6 => 'AdjustVolume',
        \App\Enums\FeatureEnum::l7 => 'MuteVolume',
        \App\Enums\FeatureEnum::l8 => 'AirPlanMode',
        \App\Enums\FeatureEnum::l9 => 'StatusBar',
        \App\Enums\FeatureEnum::us => 'UserName',
        \App\Enums\FeatureEnum::pa => 'Password',
//        \App\Enums\FeatureEnum::ki => 'KioskPackageName',
//        \App\Enums\FeatureEnum::ap => 'AdmissiblePackageNames',
    ],
    \App\Enums\RoleEnum::class => [
        \App\Enums\RoleEnum::admin => 'مدیر',
        \App\Enums\RoleEnum::user => 'کاربر',
    ],
    \App\Enums\DeviceAppStatusEnum::class => [
        \App\Enums\DeviceAppStatusEnum::install => 'در صف نصب',
        \App\Enums\DeviceAppStatusEnum::uninstall => 'در صف حذف نصب',
        \App\Enums\DeviceAppStatusEnum::installed => 'نصب شده',
        \App\Enums\DeviceAppStatusEnum::uninstalled => 'حذف نصب شده',
    ],
    \App\Enums\ConfigTypeEnum::class => [
        \App\Enums\ConfigTypeEnum::all => 'برای همه دستگاه ها',
        \App\Enums\ConfigTypeEnum::device => 'برای دستگاه انتخابی',
    ],

];
