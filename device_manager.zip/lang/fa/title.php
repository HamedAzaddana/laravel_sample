<?php


return [
    'app_name'=>'تی تایم',
    'courses'=>'دوره ها',
    'profile'=>'پروفایل',
    'settings'=>'تنظیمات',
    'setting'=>'تنظیمات',
    'billing'=>'مالی',
    'logout'=>'خروج',
    'login'=>'ورود',
    'search'=>'جستجو',
    'choose'=>'انتخاب کنید',
    'fill_form'=>'لطفا همه مقادیر ستاره دار را تکمیل نمائید.',
    'define_office_location'=>'موقعیت دفتر را مشخص کنید.',
    'create_new_record'=>'ثبت رکورد جدید',
    'add_office_row'=>'افزودن به دفتر جدید',
];
