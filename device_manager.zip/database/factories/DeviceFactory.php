<?php

namespace Database\Factories;

use App\Models\App;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Tag>
 */
class DeviceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $app = App::inRandomOrder()->first();
        return [
            'fcm_token' => fake()->randomLetter,
            'token' => fake()->unique()->randomKey,
            'app_id' => $app->id
        ];
    }
}
