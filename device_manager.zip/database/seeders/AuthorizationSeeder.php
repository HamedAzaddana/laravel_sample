<?php

namespace Database\Seeders;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Permission;
use App\Models\Role;

class AuthorizationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [];
        foreach (PermissionEnum::getValues() as $value) {
            Permission::firstOrCreate([
                'title' => PermissionEnum::getDescription($value),
                'name' => $value,
                'guard_name' => 'web',
            ]);
        }
        foreach (RoleEnum::getValues() as $value) {
            $role = Role::firstOrCreate([
                'title' => RoleEnum::getDescription($value),
                'name' => $value,
                'guard_name' => 'web',
            ]);
            $roles[] = $role->id;
        }
        $user = User::firstOrCreate([
            'username' => 'admin',
            'password' => Hash::make('123@123'),
        ]);
        $user->roles()->sync($roles);
    }
}
