<?php

namespace Database\Seeders;

use App\Enums\FeatureEnum;
use App\Enums\FeatureTypeEnum;
use App\Models\Feature;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class FeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $textFeatures = [
            FeatureEnum::us,
            FeatureEnum::pa,
            FeatureEnum::ki,
        ];
        $listFeatures = [
            FeatureEnum::ap,
        ];
        foreach (FeatureEnum::getValues() as $value) {
            $type = FeatureTypeEnum::boolean;
            if (in_array($value, $textFeatures)) {
                $type = FeatureTypeEnum::string;
            } elseif (in_array($value, $listFeatures)) {
                $type = FeatureTypeEnum::list;
            }
            Feature::firstOrCreate([
                'title' => FeatureEnum::getDescription($value),
                'type' => $type,
                'key' => $value
            ]);
        }
    }
}
