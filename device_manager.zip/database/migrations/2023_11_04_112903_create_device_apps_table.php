<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('device_apps', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('device_id')->index();
            $table->string('title')->index()->nullable();
            $table->string('package_name')->index();
            $table->string('path')->nullable();
            $table->enum('status', \App\Enums\DeviceAppStatusEnum::getValues())->default(\App\Enums\DeviceAppStatusEnum::installed)->index();
            $table->timestamps();
            $table->index(['device_id', 'status']);
            $table->unique(['device_id', 'package_name']);
            $table->foreign('device_id')->on('devices')->references('id')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('device_apps');
    }
};
