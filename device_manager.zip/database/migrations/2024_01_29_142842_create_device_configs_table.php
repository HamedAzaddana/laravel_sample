<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('device_configs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('device_id')->index();
            $table->unsignedBigInteger('config_id')->index();
            $table->enum('status',\App\Enums\DeviceConfigStatusEnum::getValues())->default(\App\Enums\DeviceConfigStatusEnum::pending)->index();
            $table->unique(['device_id','config_id']);
            $table->index(['device_id','config_id','status']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('device_configs');
    }
};
