<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('features', function (Blueprint $table) {
            $table->id();
            $table->string('key')->index();
            $table->enum('type',\App\Enums\FeatureTypeEnum::getValues())->index();
            $table->string('title')->index();
        });
        Schema::create('app_features', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('app_id')->index();
            $table->unsignedBigInteger('feature_id')->index();

            $table->foreign('app_id')->on('apps')->references('id')->cascadeOnDelete();
            $table->foreign('feature_id')->on('features')->references('id')->cascadeOnDelete();

            $table->unique(['feature_id', 'app_id']);

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('app_features');
        Schema::dropIfExists('features');
    }
};
