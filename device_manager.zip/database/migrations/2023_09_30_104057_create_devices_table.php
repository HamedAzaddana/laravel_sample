<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('devices', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable()->index();
            $table->string('number')->nullable()->index();
            $table->string('fcm_token')->nullable()->index();
            $table->string('token')->unique()->nullable()->index();
            $table->string('device')->nullable()->index();
            $table->string('product')->nullable()->index();
            $table->string('model')->nullable()->index();
            $table->string('manufacturer')->nullable()->index();
            $table->string('android_version')->nullable()->index();
            $table->string('android_api')->nullable()->index();
            $table->string('battery_level')->nullable()->index();
            $table->unsignedBigInteger('app_id')->index();
            $table->foreign('app_id')->on('apps')->references('id')->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('devices');
    }
};
