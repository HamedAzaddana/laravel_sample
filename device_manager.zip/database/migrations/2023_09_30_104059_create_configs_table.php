<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('configs', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable()->index();
            $table->enum('type',\App\Enums\ConfigTypeEnum::getValues())->nullable()->index();
            $table->text('config');
            $table->string('qr_code');

            $table->unsignedBigInteger('device_id')->nullable()->index();
            $table->unsignedBigInteger('app_id')->index();

            $table->foreign('device_id')->on('devices')->references('id')->cascadeOnDelete();
            $table->foreign('app_id')->on('apps')->references('id')->cascadeOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('configs');
    }
};
