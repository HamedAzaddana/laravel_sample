<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('device_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('device_id')->index();
            $table->string('message_id')->nullable()->index();
            $table->string('thread_id')->nullable()->index();
            $table->string('person')->nullable()->index();
            $table->string('address')->nullable()->index();
            $table->string('type')->nullable()->index();
            $table->string('protocol')->nullable()->index();
            $table->string('service_center')->nullable()->index();
            $table->text('body')->nullable();
            $table->unsignedBigInteger('time')->nullable()->index();
            $table->boolean('is_read')->nullable()->default(false)->index();
            $table->enum('status', \App\Enums\DeviceMessageStatusEnum::getValues())->default(\App\Enums\DeviceMessageStatusEnum::sent)->index();
            $table->timestamps();
            $table->index(['device_id', 'status']);
            $table->foreign('device_id')->on('devices')->references('id')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('device_messages');
    }
};
