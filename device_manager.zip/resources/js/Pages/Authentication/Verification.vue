<script setup>
import Checkbox from '@/Components/Checkbox.vue';
import GuestLayout from '@/Layouts/AuthenticationLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import {Head, Link, useForm} from '@inertiajs/vue3';
import AuthenticationLayout from "@/Layouts/AuthenticationLayout.vue";

defineProps({
    canResetPassword: {
        type: Boolean,
    },
    status: {
        type: String,
    },
});

const form = useForm({
    phone: '',
});

const submit = () => {
    form.post(route('authentication.verification'));
};
</script>

<template>
    <AuthenticationLayout>
<!--        <Head title="سامانه مدیریت کارپویه"/>-->

        <form @submit.prevent="submit">
            <div>
                <InputLabel for="phone" value="شماره همراه"/>

                <TextInput
                    id="phone"
                    type="number"
                    class="mt-1 block w-full"
                    v-model="form.phone"
                    required
                    autofocus
                    autocomplete="phone"
                />

                <InputError class="mt-2" :message="form.errors.message"/>
            </div>
            <div class="flex items-center justify-start mt-4">
                <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">دریافت کد تایید</PrimaryButton>
            </div>
        </form>
    </AuthenticationLayout>
</template>
