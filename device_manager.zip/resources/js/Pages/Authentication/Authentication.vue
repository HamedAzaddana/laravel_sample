<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import {Head, Link, useForm} from '@inertiajs/vue3';
import AuthenticationLayout from "@/Layouts/AuthenticationLayout.vue";

const props = defineProps({
    message: {
        type: String,
    },
});

const form = useForm({
    username:'',
    password: '',
});

const submit = () => {
    form.post(route('authentication'));
};
</script>

<template>
    <AuthenticationLayout>
        <Head title="سامانه مدیریت دستگاه ها"/>

        <form @submit.prevent="submit">
            <div>
                <InputLabel for="username" value="نام کاربری"/>

                <TextInput
                    id="username"
                    type="text"
                    class="mt-1 block w-full"
                    v-model="form.username"
                    required
                    autofocus
                />

                <InputError class="mt-2" :message="form.errors.username"/>
            </div>
            <div>
                <InputLabel for="phone" value="رمزعبور"/>

                <TextInput
                    id="password"
                    type="password"
                    class="mt-1 block w-full"
                    v-model="form.password"
                    required
                />

                <InputError class="mt-2" :message="form.errors.password"/>
            </div>
            <div class="flex items-center justify-start mt-4">
                <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">ورود</PrimaryButton>
            </div>
        </form>
    </AuthenticationLayout>
</template>
