<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Pagination from '@/Components/Pagination.vue';
import {Head, Link} from '@inertiajs/vue3';
import "leaflet/dist/leaflet.css"
import {LMarker, LMap, LTileLayer, LPopup, LPolyline, LCircleMarker} from "@vue-leaflet/vue-leaflet"
import {io} from "socket.io-client";
import {ref, reactive} from "vue";

import "leaflet/dist/leaflet.css";
import L from "leaflet";
// import "../public/Tween.js";
// import "../public/leaflet.curve.js";

let lat = 35.699742;
let long = 51.338984;
// let map=ref(null)
// let marker=ref('marker')
const state = reactive({
  connected: false,
  fooEvents: [],
  barEvents: [],
  vs: false
});
const socket = io("ws://localhost:8085", {
  transports: ['websocket'],
  query: {
    "room": "a"
  }
});

socket.on("connect", () => {
  state.connected = true;
});

socket.on("disconnect", () => {
  state.connected = false;
});
let mapp;
let marker;
socket.on("get_location", (...data) => {
  lat = data[0].lat;
  long = data[0].lng;
  marker.remove()
  marker = L.marker([lat, long]);
  marker.addTo(mapp)
  mapp.flyTo([lat, long])
});


setTimeout(() => {
  mapp = L.map("mapContainer").setView([lat, long], 17);
  L.tileLayer("http://{s}.tile.osm.org/{z}/{x}/{y}.png", {
    attribution:
        '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(mapp);
  marker = L.marker([lat, long]);
  marker.addTo(mapp)
}, 1000)


setTimeout(() => {

}, 5000)
</script>

<template>
  <Head title="ردیابی"/>

  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">ردیابی</h2>
    </template>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <div id="mapContainer" class="w-full col-span-2" style="height: 80vh">
      </div>

    </div>
  </AuthenticatedLayout>
</template>
