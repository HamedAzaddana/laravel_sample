<script setup>

import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import {Head, Link, useForm, router} from '@inertiajs/vue3';
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";

const props = defineProps({
  data: {
    type: Object,
  },
  apps: Array
});

const form = useForm({
  title: props.data.title,
  number: props.data.number,
  fcm_token: props.data.fcm_token,
  token: props.data.token,
  device: props.data.device,
  product: props.data.product,
  model: props.data.model,
  manufacturer: props.data.manufacturer,
  android_version: props.data.android_version,
  android_api: props.data.android_api,
  battery_level: props.data.battery_level,
  app_id: (props.data.app_id === undefined || props.data.app_id == null) && props.apps.length > 0 ? props.apps[0].id : props.data.app_id,
});

const submit = () => {
  // if (props.data.id !== undefined && props.data.id != null) {
  form.post(route('devices.update', {id: props.data.id}), {
    // onSuccess: (data) => router.visit(route('events.edit', {id:data.props.data.id}))
    onSuccess: (data) => {

    }
  });
  // } else {
  //   form.post(route('devices.store'), {
  //     onSuccess: (data) => {
  //       form.reset()
  //     }
  //   });
  // }

};

</script>

<template>
  <Head title="سامانه مدیریت از راه دور دستگاه"/>
  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">ایجاد دستگاه</h2>
    </template>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <form @submit.prevent="submit">
        <h1>آخرین بروزرسانی: <span dir="ltr">{{ props.data.jalali_date }}</span></h1>
        <div class="grid grid-cols-2 gap-4">
          <div class="">
            <InputLabel for="title" value="عنوان"/>
            <TextInput
                id="title"
                type="text"
                class="mt-1 block w-full"
                v-model="form.title"
                required
                autofocus
                autocomplete="title"
            />
            <InputError class="mt-2" :message="form.errors.title"/>
          </div>
          <div>
            <InputLabel for="app_id" value="برنامه"/>
            <select disabled
                    class="mt-1 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
                    name="roles" v-model="form.app_id">
              <option v-for="item in props.apps" :value="item.id">{{ item.title }}</option>
            </select>
            <InputError class="mt-2" :message="form.errors.app_id"/>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div class="mt-4">
            <InputLabel for="number" value="شماره سیم کارت دستگاه"/>
            <TextInput disabled
                       id="number"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.number"
            />
            <InputError class="mt-2" :message="form.errors.number"/>
          </div>
          <div class="mt-4">
            <InputLabel for="device" value="نام دستگاه"/>
            <TextInput disabled
                       id="device"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.device"
            />
            <InputError class="mt-2" :message="form.errors.device"/>
          </div>
          <div class="mt-4">
            <InputLabel for="product" value="سری محصول"/>
            <TextInput disabled
                       id="product"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.product"
            />
            <InputError class="mt-2" :message="form.errors.product"/>
          </div>
          <div class="mt-4">
            <InputLabel for="model" value="مدل دستگاه"/>
            <TextInput disabled
                       id="model"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.model"
            />
            <InputError class="mt-2" :message="form.errors.model"/>
          </div>
          <div class="mt-4">
            <InputLabel for="manufacturer" value="برند سازنده"/>
            <TextInput disabled
                       id="manufacturer"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.manufacturer"
            />
            <InputError class="mt-2" :message="form.errors.manufacturer"/>
          </div>
          <div class="mt-4">
            <InputLabel for="android_version" value="نسخه اندروید"/>
            <TextInput disabled
                       id="android_version"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.android_version"
            />
            <InputError class="mt-2" :message="form.errors.android_version"/>
          </div>
          <div class="mt-4">
            <InputLabel for="android_api" value="نسخه api اندروید"/>
            <TextInput disabled
                       id="android_api"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.android_api"
            />
            <InputError class="mt-2" :message="form.errors.android_api"/>
          </div>
          <div class="mt-4">
            <InputLabel for="battery_level" value="درصد باتری"/>
            <TextInput disabled
                       id="battery_level"
                       type="text"
                       class="mt-1 block w-full"
                       v-model="form.battery_level"
            />
            <InputError class="mt-2" :message="form.errors.battery_level"/>
          </div>
        </div>
        <div class="mt-4">
          <InputLabel for="token" value="شناسه یکتا"/>
          <TextInput disabled
                     id="token"
                     type="text"
                     class="mt-1 block w-full"
                     v-model="form.token"
          />
          <InputError class="mt-2" :message="form.errors.token"/>
        </div>
        <div class="mt-4">
          <InputLabel for="fcm_token" value="شناسه یکتا فایربیس"/>
          <TextInput disabled
                     id="fcm_token"
                     type="text"
                     class="mt-1 block w-full"
                     v-model="form.fcm_token"
          />
          <InputError class="mt-2" :message="form.errors.fcm_token"/>
        </div>
        <div class="flex items-center justify-start mt-4">
          <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
            ارسال
          </PrimaryButton>
        </div>
      </form>
    </div>
  </AuthenticatedLayout>
</template>
