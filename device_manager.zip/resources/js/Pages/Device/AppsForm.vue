<script setup>

import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import {Head, Link, useForm, router} from '@inertiajs/vue3';
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";

const props = defineProps({
  data: {
    type: Object,
  },
  device_id: Number
});

const form = useForm({
  title: '',
  package_name: '',
  file: null,
});

const submit = () => {
  // if (props.data.id !== undefined && props.data.id != null) {
  form.post(route('devices.apps.store', {id: props.device_id}), {
    // onSuccess: (data) => router.visit(route('events.edit', {id:data.props.data.id}))
    onSuccess: (data) => {

    }
  });
  // } else {
  //   form.post(route('devices.store'), {
  //     onSuccess: (data) => {
  //       form.reset()
  //     }
  //   });
  // }

};

</script>

<template>
  <Head title="سامانه مدیریت از راه دور دستگاه"/>
  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">نصب برنامه جدید برروی دستگاه</h2>
    </template>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <form @submit.prevent="submit">
        <div class="grid grid-cols-3 gap-4">
          <div class="">
            <InputLabel for="title" value="عنوان برنامه"/>
            <TextInput
                id="title"
                type="text"
                class="mt-1 block w-full"
                v-model="form.title"
                required
                autofocus
                autocomplete="title"
            />
            <InputError class="mt-2" :message="form.errors.title"/>
          </div>
          <div class="">
            <InputLabel for="package_name" value="پکیج نیم برنامه"/>
            <TextInput
                id="package_name"
                type="text"
                class="mt-1 block w-full"
                v-model="form.package_name"
                required
                autocomplete="package_name"
            />
            <InputError class="mt-2" :message="form.errors.package_name"/>
          </div>
          <div>
            <InputLabel for="file" value="فایل apk"/>
            <input
                id="image"
                type="file"
                required
                class="rounded-md mt-1 block w-full"
                @input="form.file = $event.target.files[0]"
            />
            <progress v-if="form.progress" :value="form.progress.percentage" max="100">
              {{ form.progress.percentage }}%
            </progress>
            <span v-if="form.file"><a class="text-blue-700 font-bold"
                                      :href="'/storage/'+form.file"
                                      target="_blank">مشاهده</a></span>
            <InputError class="mt-2" :message="form.errors.file"/>
          </div>
        </div>
        <div class="flex items-center justify-start mt-4">
          <PrimaryButton class="ml-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
            ارسال
          </PrimaryButton>
        </div>
      </form>
    </div>
  </AuthenticatedLayout>
</template>
