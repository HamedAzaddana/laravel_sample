<script setup>
import InputError from "@/Components/InputError.vue";
import InputLabel from "@/Components/InputLabel.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import TextInput from "@/Components/TextInput.vue";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import Pagination from "@/Components/Pagination.vue";
import { Head, Link } from "@inertiajs/vue3";
import "leaflet/dist/leaflet.css";
import "@majidh1/jalalidatepicker/dist/jalalidatepicker.min.css";
import "@majidh1/jalalidatepicker/dist/jalalidatepicker.min.js";
import L from "leaflet";
import { onMounted, reactive } from "vue";
import { router } from "@inertiajs/vue3";
import { get_query_param_url, set_query_param_url } from "@/Utils/helpers";

const state = reactive({
  radiusMapForm: 0,
  circleMapForm: null,
  markerMapForm: null,
  clickedLat: 0,
  clickedLong: 0,
  mapDiv: null,
  zoomMap: 14,
});
const props = defineProps({
  data: Object,
  today: String,
  filters: Array,
});

const showMarkerOnMap = (lat, lng, e) => {
  Array.prototype.forEach.call(
    document.getElementsByClassName("marker-set-point"),
    function (el) {
      el.style.background = "";
      el.style.borderColor = "";
      el.style.color = "";
    }
  );
  e.currentTarget.style.background = "#56a14a";
  e.currentTarget.style.borderColor = "rgb(20 75 11)";
  e.currentTarget.style.color = "white";
  var newLatLng = new L.LatLng(lat, lng);
  state.markerMapForm = state.markerMapForm.setLatLng(newLatLng);
  state.circleMapForm = state.circleMapForm.setLatLng(newLatLng);
  state.clickedLat = lat;
  state.clickedLong = lng;
  window.scrollTo({ top: 0, behavior: "smooth" });
  state.mapDiv.panTo(new L.LatLng(lat, lng));
};
const setMapView = (all = 0) => {
  let radius = state.radiusMapForm;
  const mapDiv = L.map("mapContainer").setView(
    [props?.data[0]?.lat ?? 0, props?.data[0]?.long ?? 0],
    radius
  );
  mapDiv.setZoom(state.zoomMap);

  let markerClick = L.marker([0, 0]).addTo(mapDiv);
  let circleClick = L.circle([0, 0], {
    radius: radius,
  }).addTo(mapDiv);
  state.markerMapForm = markerClick;
  state.circleMapForm = circleClick;
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(mapDiv);
  if (all == 1) {
    for (let i = 0; i < props.data.length; i++) {
      let marker = L.marker([props.data[i].lat, props.data[i].long]).addTo(mapDiv);
      let circle = L.circle([props.data[i].lat, props.data[i].long], {
        radius: radius,
      }).addTo(mapDiv);
    }
  }

  mapDiv.on("click", function (e) {
    var lat = e.latlng.lat;
    var lng = e.latlng.lng;
    var newLatLng = new L.LatLng(lat, lng);
    state.markerMapForm = markerClick.setLatLng(newLatLng);
    state.circleMapForm = circleClick.setLatLng(newLatLng);
    state.clickedLat = lat;
    state.clickedLong = lng;
  });
  state.mapDiv = mapDiv;
};
const currentFullUrl = window.location.href;
const onChangeFilters = (e) => {
  props.filters[e.target.getAttribute("name")] = e.target.value;
};
const filtersOn = (e) => {
  let newLink = "";
  props.filters.date_filter =
    props?.filters?.date_filter == null ? "" : props?.filters?.date_filter;
  newLink = set_query_param_url(
    currentFullUrl,
    "date_filter",
    props?.filters?.date_filter
  );
  router.visit(newLink, { method: "get" });
};
onMounted(() => {
  setMapView(0);
  Array.prototype.forEach.call(
    document.getElementsByClassName("leaflet-marker-icon"),
    function (el) {
      el.src = "/images/marker-icon-leaflet-small.png";
    }
  );
  Array.prototype.forEach.call(
    document.getElementsByClassName("leaflet-marker-shadow"),
    function (el) {
      el.src = "/images/marker-shadow-leaflet.png";
      el.style.display = "none";
    }
  );
  jalaliDatepicker.startWatch();
});
</script>
<style scoped>
select {
  cursor: pointer;
}
.leaflet-container {
  border-radius: 5px !important;
}
input[type="checkbox"] {
  cursor: pointer !important;
}
#mapContainer {
  width: 50vw;
  height: 35vh;
}
tr,
td {
  text-align: center !important;
}
</style>
<template>
  <Head title="لیست لوکیشن ها" />
  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">لیست لوکیشن ها</h2>
    </template>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <div class="grid grid-cols-8 gap-4">
        <div class="mt-1 mb-2 col-span-3">
          <InputLabel for="title" value="تاریخ" />
          <TextInput
            data-jdp
            id="date_filter"
            name="date_filter"
            @input="onChangeFilters($event)"
            :value="props?.filters?.date_filter"
            type="text"
            class="block w-full"
            required
          />
        </div>
        <div class="mt-5 col-span-1">
          <button
            style="cursor: pointer"
            type="button"
            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 mt-1 px-4 rounded"
            @click="filtersOn"
          >
            <i class="fa fa-search"></i> جستجو
          </button>
        </div>
        <div class="mt-1 mb-2 col-span-3"></div>
        <div class="mt-1 col-span-4">
          <table class="min-w-full text-right text-sm font-light">
            <thead class="border-b font-medium dark:border-neutral-500">
              <tr>
                <th width="30%" scope="col" class="px-6 py-4">تاریخ شروع</th>
                <th width="30%" scope="col" class="px-6 py-4">تاریخ پایان</th>
                <th width="30%" scope="col" class="px-6 py-4">مشاهده</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="(item, index) in props.data"
                class="border-b dark:border-neutral-500"
              >
                <td
                  class="whitespace-nowrap px-6 py-4 font-medium"
                  style="direction: ltr"
                >
                  {{ item.start_jalali_date }}
                </td>
                <td
                  class="whitespace-nowrap px-6 py-4 font-medium"
                  style="direction: ltr"
                >
                  {{ item.end_jalali_date }}
                </td>
                <td>
                  <button
                    @click="showMarkerOnMap(item.lat, item.long, $event)"
                    type="button"
                    class="marker-set-point bg-blue-400 hover:bg-blue-400 text-white font-bold py-1 px-2 border-b-4 border-blue-700 hover:border-blue-500 rounded"
                  >
                    <i class="fa fa-map-marker"></i>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="mt-1 col-span-4">
          <div id="mapContainer"></div>
        </div>
      </div>
    </div>
  </AuthenticatedLayout>
</template>
