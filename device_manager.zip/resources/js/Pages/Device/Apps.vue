<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Pagination from '@/Components/Pagination.vue';
import {Head, Link} from '@inertiajs/vue3';
import SecondaryButton from "@/Components/SecondaryButton.vue";
import PrimaryButton from '@/Components/PrimaryButton.vue';

const props = defineProps({
  data: {
    type: Object,
  },
  device_id: Number
});
</script>

<template>
  <Head title="لیست برنامه ها"/>

  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">لیست برنامه ها</h2>
    </template>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <PrimaryButton><a class="font-bold" :href="route('devices.apps.create',{'device_id':props.device_id})">نصب برنامه جدید
        +</a></PrimaryButton>
      <table class="min-w-full text-right text-sm font-light">
        <thead class="border-b font-medium dark:border-neutral-500">
        <tr>
          <th width="10%" scope="col" class="px-6 py-4">ردیف</th>
          <th width="20%" scope="col" class="px-6 py-4">نام برنامه</th>
          <th width="20%" scope="col" class="px-6 py-4">پکیج نیم</th>
          <th width="20%" scope="col" class="px-6 py-4">وضعیت برنامه</th>
          <th width="20%" scope="col" class="px-6 py-4">عملیات</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="(item,index) in data.data" class="border-b dark:border-neutral-500">
          <td class="whitespace-nowrap px-6 py-4 font-medium">
            {{ data.from + index }}
          </td>
          <td class="whitespace-nowrap px-6 py-4 text-blue-500">
            {{ item.title }}
          </td>
          <td class="whitespace-nowrap px-6 py-4 text-blue-500">
            {{ item.package_name }}
          </td>
          <td class="whitespace-nowrap px-6 py-4 text-blue-500">
            {{ item.status_title }}
          </td>
          <td class="whitespace-nowrap px-6 py-4">
            <Link v-if="item.status!=='installed' && item.status!=='install' && item.status!=='uninstall'" class="text-blue-500 font-bold" :href="route('devices.apps.status',{id:item.id,device_id:props.device_id,status:'install'})">
              نصب /
            </Link>
            <Link v-if="item.status!=='uninstalled' && item.status!=='uninstall' && item.status!=='install'" class="text-orange-400 font-bold" :href="route('devices.apps.status',{id:item.id,device_id:props.device_id,status:'uninstall'})">
              حذف نصب /
            </Link>
            <Link class="text-red-500 font-bold" :href="route('devices.apps.delete',{id:item.id,device_id:props.device_id})">حذف</Link>
          </td>
        </tr>
        </tbody>
      </table>
      <Pagination class="mt-6" :links="data.links"/>
    </div>
  </AuthenticatedLayout>
</template>
