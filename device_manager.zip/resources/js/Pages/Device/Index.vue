<script setup>
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import Pagination from "@/Components/Pagination.vue";
import { Head, Link } from "@inertiajs/vue3";
import TextInput from "@/Components/TextInput.vue";
import { onBeforeMount, onMounted } from "vue";
import { router } from '@inertiajs/vue3'
import { get_query_param_url, set_query_param_url } from "@/Utils/helpers";
import { usePage } from "@inertiajs/vue3";
import Swal from "sweetalert2";

const page = usePage();
const props = defineProps({
  data: {
    type: Object,
  },
  apps_all: Array,
  filters: Array,
  defaultAppUserId:Number
});
const currentFullUrl = window.location.href;

const onChangeFilters = (e) => {
  props.filters[e.target.getAttribute("name")] = e.target.value;
};
const filtersOn = (e) => {
  let newLink = "";
  props.filters.device_title = props?.filters?.device_title == null ? "":props?.filters?.device_title;
  props.filters.device_app = props?.filters?.device_app == "0" || props?.filters?.device_app==null ? 0:props?.filters?.device_app;
  newLink = set_query_param_url(currentFullUrl, "device_app", parseInt(props?.filters?.device_app));
  newLink = set_query_param_url(newLink, "device_title", String(props?.filters?.device_title));
  router.visit(newLink, { method: 'get' })
};
onBeforeMount(() => {
  props.filters.device_title = props?.filters?.device_title == null ? "":props?.filters?.device_title;
  props.filters.device_app = props?.filters?.device_app == "0" || props?.filters?.device_app==null ? 0:props?.filters?.device_app;
});
onMounted(()=>{
  if (page.props.flash.confirm_swal) {
    Swal.fire({
      title: "اخطار !",
      text: page.props.flash.confirm_swal.message,
      icon: "question",
      iconHtml: "؟",
      confirmButtonText: "بله",
      cancelButtonText: "خیر",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      showCancelButton: true,
      showCloseButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        router.visit(
          route("devices.wipe_configs", { id: page.props.flash.confirm_swal.data.id }) +
            "/?confirmation=true",
          { method: "get" }
        );
      }
    });
  }
})
</script>

<template>
  <Head title="لیست دستگاه ها" />

  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">لیست دستگاه ها</h2>
    </template>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <div class="grid grid-cols-3 gap-3 mt-4">
        <div class="" v-if="!props.defaultAppUserId">
          <select
            style="cursor: pointer"
            class="mt-1 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
            name="device_app"
            @input="onChangeFilters($event)"
            :selected="props?.filters?.device_app"
            :value="props?.filters?.device_app"
          >
            <option value="0">- پکیج انتخابی -</option>
            <option v-for="item in props.apps_all" :value="item.id">
              {{ item.title }}
            </option>
          </select>
        </div>

        <div class="">
          <TextInput
            style="cursor: pointer"
            type="text"
            class="mt-1 block w-full"
            autocomplete="device_title_user"
            placeholder="عنوان دستگاه"
            name="device_title"
            @input="onChangeFilters($event)"
            :value="props?.filters?.device_title"
          />
        </div>
        <div class="">
          <button
            style="cursor: pointer"
            type="button"
            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 mt-1 px-4 rounded"
            @click="filtersOn"
          >
            <i class="fa fa-search"></i> جستجو
          </button>
        </div>
      </div>
      <div v-if="!data.data.length">
        <div
          class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 mt-5 rounded relative"
          role="alert"
        >
          <span class="block sm:inline">نتیجه ای یافت نشد.</span>
        </div>
      </div>
      <!--            <PrimaryButton><a class="font-bold" :href="route('devices.create')">ایجاد دستگاه جدید +</a></PrimaryButton>-->
      <table v-if="data.data.length" class="min-w-full text-right text-sm font-light">
        <thead class="border-b font-medium dark:border-neutral-500">
          <tr>
            <th width="10%" scope="col" class="px-6 py-4">ردیف</th>
            <th width="20%" scope="col" class="px-6 py-4">عنوان</th>
            <th width="20%" scope="col" class="px-6 py-4">برنامه</th>
            <th width="20%" scope="col" class="px-6 py-4">عملیات</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in data.data" class="border-b dark:border-neutral-500">
            <td class="whitespace-nowrap px-6 py-4 font-medium">
              <Link :href="route('devices.edit', { id: item.id })">{{
                data.from + index
              }}</Link>
            </td>
            <td class="whitespace-nowrap px-6 py-4">
              <Link :href="route('devices.edit', { id: item.id })">{{ item.title }}</Link>
            </td>
            <td class="whitespace-nowrap px-6 py-4">
              <Link :href="route('devices.edit', { id: item.id })">{{
                item.app.title
              }}</Link>
            </td>
            <td class="whitespace-nowrap px-6 py-4">
              <Link
                class="text-blue-500 font-bold"
                :href="route('devices.edit', { id: item.id })"
                >ویرایش</Link
              >
              /
              <Link
                class="text-red-400 font-bold"
                :href="route('devices.wipe_configs', { id: item.id })"
                >Wipe</Link>
              /
              <Link
                class="text-pink-900 font-bold"
                :href="route('devices.apps.index', { device_id: item.id })"
                >برنامه ها</Link
              >
              /
              <Link
                class="text-purple-800 font-bold"
                :href="route('devices.locations.index', { device_id: item.id })"
                >لوکیشن ها</Link
              >
              /
              <Link
                class="text-green-800 font-bold"
                :href="route('devices.tracker.index', { device_id: item.id })"
                >ردیابی</Link
              >
              /
              <Link
                class="text-pink-500 font-bold"
                :href="route('devices.messages.index', { device_id: item.id })"
                >پیامک ها</Link
              >
              /
              <Link
                class="text-red-500 font-bold"
                :href="route('devices.delete', { id: item.id })"
                >حذف</Link
              >
            </td>
          </tr>
        </tbody>
      </table>
      <Pagination class="mt-6" :links="data.links" />
    </div>
  </AuthenticatedLayout>
</template>
