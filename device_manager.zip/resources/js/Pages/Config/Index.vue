<script setup>
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import Pagination from "@/Components/Pagination.vue";
import { Head, Link } from "@inertiajs/vue3";
import SecondaryButton from "@/Components/SecondaryButton.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import { ref, onMounted } from "vue";
import { usePage } from "@inertiajs/vue3";
const page = usePage();
import Swal from "sweetalert2";
import { router } from "@inertiajs/vue3";
onMounted(() => {
  if (page.props.flash.confirm_swal) {
    Swal.fire({
      title: "اخطار !",
      text: page.props.flash.confirm_swal.message,
      icon: "question",
      iconHtml: "؟",
      confirmButtonText: "بله",
      cancelButtonText: "خیر",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      showCancelButton: true,
      showCloseButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        router.visit(
          route("configs.delete", { id: page.props.flash.confirm_swal.data.id }) +
            "/?confirmation=true",
          { method: "get" }
        );
      }
    });
  }
});
const props = defineProps({
  data: {
    type: Object,
  },
});
</script>

<template>
  <Head title="لیست دسته بندی ها" />

  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">لیست تنظیمات</h2>
    </template>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <Link
        class="font-bold inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
        :href="route('configs.create')"
        >ایجاد تنظیمات جدید +</Link
      >
      <table class="min-w-full text-right text-sm font-light">
        <thead class="border-b font-medium dark:border-neutral-500">
          <tr>
            <th width="10%" scope="col" class="px-6 py-4">ردیف</th>
            <th width="70%" scope="col" class="px-6 py-4">عنوان</th>
            <th width="20%" scope="col" class="px-6 py-4">عملیات</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in data.data" class="border-b dark:border-neutral-500">
            <td class="whitespace-nowrap px-6 py-4 font-medium">
              <Link :href="route('configs.edit', { id: item.id })">{{
                data.from + index
              }}</Link>
            </td>
            <td class="whitespace-nowrap px-6 py-4">
              <Link :href="route('configs.edit', { id: item.id })">{{ item.title }}</Link>
            </td>
            <td class="whitespace-nowrap px-6 py-4">
              <Link
                class="text-blue-500 font-bold"
                :href="route('configs.edit', { id: item.id })"
                >ویرایش</Link
              >
              /
              <Link
                class="text-red-500 font-bold"
                :href="route('configs.delete', { id: item.id })"
                >حذف</Link
              >
            </td>
          </tr>
        </tbody>
      </table>
      <Pagination class="mt-6" :links="data.links" />
    </div>
  </AuthenticatedLayout>
</template>
