<script setup>
import InputError from "@/Components/InputError.vue";
import InputLabel from "@/Components/InputLabel.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import TextInput from "@/Components/TextInput.vue";
import { Head, Link, useForm, router } from "@inertiajs/vue3";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import Checkbox from "@/Components/Checkbox.vue";
import { onBeforeMount, onMounted } from "vue";
import { LMap, LTileLayer, LPolyline, LCircleMarker } from "@vue-leaflet/vue-leaflet";
import { ref, reactive } from "vue";
import TextAreaInput from "@/Components/TextAreaInput.vue";
import { get_query_param_url, set_query_param_url } from "@/Utils/helpers";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import Swal from "sweetalert2";

const props = defineProps({
  data: {
    type: Object,
  },
  types: Array,
  defaultAppUserId: Number,
  features: Array,
  devices: Array,
  apps: Array,
});
const state = reactive({
  showDeviceList: false,
  showLocationForm: true,
  appSelectedId: 0,
  radiusMapForm: 0,
  circleMapForm: null,
  markerMapForm: null,
});
let initLat = 35.69967119;
let initLong = 51.338076;
let initRadius = 30;
const form = useForm({
  title: props.data.title,
  lat: props.data.lat || initLat,
  long: props.data.long || initLong,
  radius: props.data.radius || initRadius,
  tags: [],
  device_id: props.data.device_id,
  features: {},
  config: props.data.config,
  force_config: props.data.force_config,
  type: props.data ? props.data.type : "",
  app_id:
    (props.data.app_id === undefined || props.data.app_id == null) &&
    props.apps.length > 0
      ? 0
      : props.data.app_id,
});
const submit = () => {
  form.lat = form.lat == initLat ? null : form.lat;
  form.long = form.long == initLong ? null : form.long;
  form.radius = form.radius == initRadius ? null : form.radius;
  if (props.data.id !== undefined && props.data.id != null) {
    form.post(route("configs.update", { id: props.data.id }), {
      onSuccess: (data) => {},
    });
  } else {
    form.post(route("configs.store"), {
      onSuccess: (data) => {
        form.reset();
      },
    });
  }
};
const selectSecondDeviceShow = () => {
  let newStatus = false;
  if (props?.data?.type == "device") {
    newStatus = true;
  } else {
    newStatus = false;
  }
  setTimeout(function () {
    state.showDeviceList = newStatus;
  }, 500);
};
const setCheckboxNoLocation = () => {
  setTimeout(function () {
    if (form.lat == initLat && form.long == initLong && form.radius == initRadius) {
      state.showLocationForm = false;
      document.getElementById("with_no_location_check").checked = true;
    }
  }, 200);
};

const setDefaultValuesFeautures = () => {
  setTimeout(function () {
    props.features.map((feature) => {
      if (form.config) {
        if (form.config[feature.key] !== undefined) {
          form.features[feature.key] = form.config[feature.key];
          if (
            feature.type == "list" &&
            feature.key == "ap" &&
            form.config[feature.key] &&
            form.config[feature.key] !== undefined
          ) {
            form.features[feature.key] = form.config[feature.key].join("\n");
          }
        } else {
          if (feature.type == "list") {
            form.tags[feature.key] = "";
            form.features[feature.key] = "";
          } else if (feature.type == "boolean") {
            form.features[feature.key] = true;
          } else {
            form.features[feature.key] = "";
          }
        }
      } else {
        if (feature.type == "list") {
          form.tags[feature.key] = "";
          form.features[feature.key] = "";
        } else if (feature.type == "boolean") {
          form.features[feature.key] = true;
        } else {
          form.features[feature.key] = "";
        }
      }
    });
    if (props.data.force_config) {
      form.force_config = JSON.parse(props.data.force_config);
    } else {
      form.force_config = [];
    }
    form.app_id =
      form.app_id == 0 && props.defaultAppUserId ? props.defaultAppUserId : form.app_id;
  }, 1000);
};

const onChangeTypeDevice = (e) => {
  let newStatus = false;
  if (e.target.value == "device") {
    newStatus = true;
  } else {
    newStatus = false;
  }
  setTimeout(function () {
    state.showDeviceList = newStatus;
    if (!newStatus) {
      form.device_id = "";
    }
  }, 500);
};
const onChangeNoLocation = (e) => {
  if (e.target.checked) {
    setTimeout(function () {
      state.showLocationForm = false;
      form.lat = initLat;
      form.long = initLong;
      form.radius = initRadius;
    }, 500);
  } else {
    setTimeout(function () {
      state.showLocationForm = true;
    }, 500);
  }
};
const setDeviceAccordingToApp = () => {
  setTimeout(function () {
    state.appSelectedId = parseInt(props?.data?.app_id);
  }, 500);
};
const onChangeApp = (e) => {
  setTimeout(function () {
    state.appSelectedId = parseInt(e.target.value);
  }, 500);
};
const onChangeRadiusMap = (e) => {
  setTimeout(function () {
    state.radiusMapForm = parseFloat(e.target.value);
    state.circleMapForm = state.circleMapForm.setRadius(state.radiusMapForm);
  }, 500);
};

const setMapView = () => {
  state.radiusMapForm = form.radius;

  const mapDiv = L.map("mapContainer").setView(
    [form.lat, form.long],
    state.radiusMapForm
  );
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(mapDiv);
  let marker = L.marker([form.lat, form.long]).addTo(mapDiv);
  let circle = L.circle([form.lat, form.long], { radius: state.radiusMapForm }).addTo(
    mapDiv
  );
  state.circleMapForm = circle;
  state.markerMapForm = marker;
  mapDiv.on("click", function (e) {
    var lat = e.latlng.lat;
    var lng = e.latlng.lng;
    var newLatLng = new L.LatLng(lat, lng);
    marker = marker.setLatLng(newLatLng);
    circle = circle.setLatLng(newLatLng);
    state.circleMapForm = circle;
    state.markerMapForm = marker;
    form.lat = lat;
    form.long = lng;
  });
};

onMounted(() => {
  selectSecondDeviceShow();
  setCheckboxNoLocation();
  setDeviceAccordingToApp();
  setMapView();
  document.getElementsByClassName("leaflet-marker-icon")[0].src =
    "/images/marker-icon-leaflet.png";
  document.getElementsByClassName("leaflet-marker-shadow")[0].src =
    "/images/marker-shadow-leaflet.png";
  if (get_query_param_url("refresh", window.location.href) == "0") {
    Swal.fire({
      title: "توجه",
      text: "تنظیمات جدید افزوده شد !",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "بستن",
      icon: "success",
    });
  }
});
onBeforeMount(() => {
  setDefaultValuesFeautures();
});

const addTag = (key) => {
  if (form.tags[key] === "") return;
  form.features[key].push(form.tags[key]);
  form.tags[key] = "";
};

const deleteTag = (tag, key) => {
  form.features[key].splice(form.features[key].indexOf(tag), 1);
};
const onMapClick = (value) => {
  setTimeout(function () {
    form.lat = value.latlng.lat;
    form.long = value.latlng.lng;
  }, 100);
};
router.on("success", (event) => {
  if (get_query_param_url("refresh", window.location.href) == "1") {
    document.write("Loading");
    window.location.href = set_query_param_url(window.location.href, "refresh", 0);
  }
});
</script>
<style scoped>
select {
  cursor: pointer;
}
.leaflet-container {
  border-radius: 5px !important;
}
input[type="checkbox"] {
  cursor: pointer !important;
}
#mapContainer {
  width: 50vw;
  height: 35vh;
}
</style>

<template>
  <Head title="سامانه مدیریت از راه دور دستگاه" />
  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">ایجاد تنظیمات</h2>
    </template>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <form @submit.prevent="submit">
        <div class="grid grid-cols-7 gap-4">
          <div class="mt-1 col-span-2">
            <div class="mt-3">
              <h1 class="font-bold text-blue-500">تنظیمات کلی و دستگاه ها</h1>
            </div>
            <div class="mt-2">
              <InputLabel for="title" value="عنوان" />
              <TextInput
                id="title"
                type="text"
                class="block w-full"
                v-model="form.title"
                required
                autofocus
                autocomplete="title"
              />
              <InputError class="mt-2" :message="form.errors.title" />
            </div>
            <input
              type="hidden"
              name="app_id"
              v-model="form.app_id"
              v-if="props.data.title"
            />
            <input
              type="hidden"
              name="types"
              v-model="form.type"
              v-if="props.data.title"
            />
            <input
              type="hidden"
              name="device_id"
              v-model="form.device_id"
              v-if="props.data.title"
            />
            <div class="mt-2" v-show="!props.defaultAppUserId">
              <InputLabel for="app_id" value="برنامه" />
              <select
                class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
                name="app_id"
                v-model="form.app_id"
                @input="onChangeApp($event)"
                :disabled="props.data.title"
              >
                <option value="0">- انتخاب کنید -</option>
                <option v-for="item in props.apps" :value="item.id">
                  {{ item.title }}
                </option>
              </select>
              <InputError class="mt-2" :message="form.errors.app_id" />
            </div>
            <div class="mt-2">
              <InputLabel for="types" value="نوع" />
              <select
                class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
                name="types"
                v-model="form.type"
                @input="onChangeTypeDevice($event)"
                :disabled="props.data.title"
              >
                <option v-for="item in props.types" :value="item.key">
                  {{ item.title }}
                </option>
              </select>
              <InputError class="mt-2" :message="form.errors.type" />
            </div>
            <div class="mt-2" v-show="state.showDeviceList">
              <InputLabel for="devices" value="دستگاه ها" />
              <select
                class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
                name="device_id"
                v-model="form.device_id"
                :disabled="props.data.title"
              >
                <template v-for="item in props.devices">
                  <option
                    v-if="
                      (state.appSelectedId && state.appSelectedId == item.app_id) ||
                      defaultAppUserId
                    "
                    :value="item.id"
                  >
                    {{ item.device ? item.device : "" }}
                    {{ item.title ? "-" + item.title : " - بدون نام -" }}
                    {{ item.number ? "-" + item.number : " - بدون شماره -" }}
                  </option>
                </template>
              </select>
              <InputError class="mt-2" :message="form.errors.device_id" />
            </div>
          </div>
          <div class="mt-1 col-span-1"></div>
          <div class="mt-1 col-span-4">
            <div class="mt-3">
              <h1 class="font-bold text-blue-500">تنظیمات جغرافیایی</h1>
            </div>
            <div class="grid grid-cols-6 gap-3">
              <div class="mt-1 col-span-6">
                <Checkbox
                  id="with_no_location_check"
                  value="with_no_location"
                  class="mt-1"
                  style="cursor: pointer"
                  @input="onChangeNoLocation($event)"
                />
                <b class="mr-1 ml-1"> بدون موقعیت جغرافیایی</b>
              </div>
              <div class="w-full col-span-6" v-show="state.showLocationForm">
                <div id="container">
                  <div id="mapContainer"></div>
                </div>
              </div>

              <div v-show="state.showLocationForm" class="mt-1 col-span-2">
                <InputLabel for="radius" value="شعاع مورد پوشش دستگاه" />
                <TextInput
                  id="radius"
                  type="number"
                  class="block w-full"
                  v-model="form.radius"
                  @input="onChangeRadiusMap($event)"
                />
                <InputError class="mt-2" :message="form.errors.radius" />
              </div>
              <div class="mt-1 hidden">
                <InputLabel for="lat" value="lat" />
                <TextInput id="lat" type="text" class="block w-full" v-model="form.lat" />
                <InputError class="mt-2" :message="form.errors.lat" />
              </div>
              <div class="mt-1 hidden">
                <InputLabel for="long" value="long" />
                <TextInput
                  id="long"
                  type="text"
                  class="block w-full"
                  v-model="form.long"
                />
                <InputError class="mt-2" :message="form.errors.long" />
              </div>
            </div>
          </div>
        </div>
        <hr class="my-8 h-0.5 border-t-0 bg-neutral-100 dark:bg-white/10" />
        <div class="mt-4">
          <h1 class="font-bold text-blue-500">مقادیر تنظیمات</h1>
        </div>
        <div class="grid grid-cols-4 gap-4">
          <template v-for="item in props.features" :key="item.id">
            <div v-if="item.type == 'string'" class="mt-3">
              <InputLabel for="title" :value="item.title" />
              <TextInput
                type="text"
                class="mt-1 w-full"
                v-model="form.features[item.key]"
              />
            </div>
          </template>
        </div>
        <div class="grid grid-cols-1 gap-4">
          <template v-for="item in props.features" :key="item.id">
            <div v-if="item.type == 'list' && item.key == 'ap'" class="mt-3">
              <InputLabel for="title" :value="item.title" />
              <span class="text-red-600/75">
                * در هر خط فقط یک نام پکیج قرار دهید !
              </span>
              <TextAreaInput
                rows="10"
                id="ap_list_config"
                class="mt-1 w-full"
                v-model="form.features[item.key]"
              />
            </div>
          </template>
        </div>
        <div class="grid grid-cols-4 gap-4">
          <template v-for="item in props.features" :key="item.id">
            <div v-if="item.type == 'boolean'" class="mt-3">
              <InputLabel for="title" :value="item.title" />
              <Checkbox
                :value="item.key"
                class="mt-1"
                v-model="form.features[item.key]"
                :checked="form.features[item.key]"
              />
            </div>
          </template>
        </div>
        <hr class="my-12 h-0.5 border-t-0 bg-neutral-100 dark:bg-white/10" />

        <div class="mt-10 mb-4">
          <h1 class="font-bold text-blue-500">
            کدام یک از تنظیمات درصورت روشن نبودن اینترنت دستگاه برای دستگاه پیامک شود؟
          </h1>
        </div>
        <div class="grid grid-cols-4 gap-4">
          <template v-for="item in props.features" :key="item.id">
            <div class="mt-3">
              <InputLabel for="title" :value="item.title" />
              <input
                type="checkbox"
                :value="item.key"
                v-model="form.force_config"
                class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500"
              />
              <!--              <Checkbox-->
              <!--                  :value="item.key"-->
              <!--                  class="mt-1"-->
              <!--                  v-model="form.force_config"-->
              <!--              />-->
            </div>
          </template>
        </div>
        <!--        <template v-for="item in props.features" :key="item.id">-->
        <!--          <div v-if="item.type=='list'" class="mt-3">-->
        <!--            <InputLabel :for="item.key" :value="item.title"/>-->
        <!--            <TextInput-->
        <!--                :id="item.key"-->
        <!--                type="text"-->
        <!--                class="mt-1 block w-full"-->
        <!--                v-model="form.tags[item.key]"-->
        <!--                v-on:keypress.enter.prevent="addTag(item.key)"-->
        <!--            />-->
        <!--            <div class="flex items-center flex-wrap mt-3">-->
        <!--              <span class="py-2 invisible">:</span>-->
        <!--              <span v-for="(tag, index) in form.features[item.key]"-->
        <!--                    class="px-3 py-2 mr-1 rounded-full border border-gray-400" :key="index"><button-->
        <!--                  type="button" @click="deleteTag(tag,item.key)" class="mx-1 text-red-600">x</button>{{ tag }}</span>-->
        <!--            </div>-->
        <!--          </div>-->
        <!--        </template>-->
        <div class="flex items-center justify-start mt-4">
          <PrimaryButton
            class="ml-4"
            :class="{ 'opacity-25': form.processing }"
            :disabled="form.processing"
          >
            ارسال
          </PrimaryButton>
        </div>
      </form>
    </div>
  </AuthenticatedLayout>
</template>
