<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Pagination from '@/Components/Pagination.vue';
import {Head, Link} from '@inertiajs/vue3';
import SecondaryButton from "@/Components/SecondaryButton.vue";


const props = defineProps({
    users: {
        type: Object,
    },
});
</script>

<template>
    <Head title="لیست کاربران"/>

    <AuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">لیست کاربران</h2>
        </template>

        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
            <Link :href="route('users.create')"
              class="font-bold mx-3 inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150"> 
              ایجاد کاربر جدید 
            </Link>
            <SecondaryButton><a class="font-bold" :href="route('users.export')">خروجی اکسل کاربران</a></SecondaryButton>
            <table class="min-w-full text-right text-sm font-light">
                <thead class="border-b font-medium dark:border-neutral-500">
                <tr>
                    <th width="10%" scope="col" class="px-6 py-4">ردیف</th>
                    <th width="30%" scope="col" class="px-6 py-4">نام و نام خانوادگی</th>
                    <th width="30%" scope="col" class="px-6 py-4">نام کاربری</th>
                    <th width="30%" scope="col" class="px-6 py-4"></th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(user,index) in users.data" class="border-b dark:border-neutral-500">
                    <td class="whitespace-nowrap px-6 py-4 font-medium">{{ users.from + index }}</td>
                    <td class="whitespace-nowrap px-6 py-4">{{ user.name }}</td>
                    <td class="whitespace-nowrap px-6 py-4">{{ user.username }}</td>
                    <td class="whitespace-nowrap px-6 py-4"><Link class="font-bold" :href="route('users.edit',{'id':user.id})">ویرایش</Link></td>
                </tr>
                </tbody>
            </table>
            <Pagination class="mt-6" :links="users.links"/>
        </div>
    </AuthenticatedLayout>
</template>
