<script setup>
import InputError from "@/Components/InputError.vue";
import InputLabel from "@/Components/InputLabel.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import TextInput from "@/Components/TextInput.vue";
import { Head, Link, useForm, router } from "@inertiajs/vue3";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import TextAreaInput from "@/Components/TextAreaInput.vue";
import Checkbox from "@/Components/Checkbox.vue";
const props = defineProps({
  data: {
    type: Object,
  },
  roles: {
    type: Array,
  },
  features: {
    type: Array,
  },
  selected_roles: {
    type: Number,
  },
});

let selected_roles =
  props.data.roles !== undefined &&
  props.data.roles !== null &&
  props.data.roles.length > 0
    ? props.data.roles[0].id
    : null;
let selected_features = [];
if (props.data != null && props.data.apps != null && props.data.apps.length > 0) {
  props.data.apps[0].features.map((item) => {
    selected_features.push(item.id);
  });
}
const form = useForm({
  username: props.data.username,
  password: "",
  name: props.data.name,
  package_name:
    props.data != null && props.data.apps != null && props.data.apps.length > 0
      ? props.data.apps[0].package_name
      : "",
  roles: selected_roles,
  features: selected_features,
});

const submit = () => {
  if(route().current('users.edit')){
    form.password = !form.password ? "******" : form.password;
  }
  if (props.data.id !== undefined && props.data.id != null) {
    form.post(route("users.update", { id: props.data.id }), {
      // onSuccess: (data) => router.visit(route('events.edit', {id:data.props.data.id}))
      onSuccess: (data) => {},
    });
  } else {
    form.post(route("users.store"), {
      onSuccess: (data) => {
        form.reset();
      },
    });
  }
  form.password = "";
};
</script>
<style scoped>
select {
  cursor: pointer;
}

input[type="checkbox"] {
  cursor: pointer !important;
}
</style>
<template>
  <Head title="سامانه مدیریت از راه دور دستگاه" />
  <AuthenticatedLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">ایجاد کاربر</h2>
    </template>
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
      <form @submit.prevent="submit" autocomplete="off" novalidate>
        <div class="grid grid-cols-2 gap-4 mt-4">
          <div class="">
            <InputLabel for="name" value="نام و خانوادگی" />
            <TextInput
              id="name"
              type="text"
              class="mt-1 block w-full"
              v-model="form.name"
              required
              autofocus
              autocomplete="name"
            />
            <InputError class="mt-2" :message="form.errors.name" />
          </div>
          <div class="">
            <InputLabel for="username" value="نام کاربری" />
            <TextInput
              id="username"
              name="username"
              type="text"
              class="mt-1 block w-full"
              v-model="form.username"
              required
              autocomplete="username"
            />
            <InputError class="mt-2" :message="form.errors.username" />
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4 mt-4">
          <div class="">
            <InputLabel for="password" value="رمزعبور" />
            <TextInput
              id="password"
              type="password"
              class="mt-1 block w-full"
              v-model="form.password"
              required
              autocomplete="false"
              readonly
              onfocus="this.removeAttribute('readonly');"
            />
            <InputError class="mt-2" :message="form.errors.password" />
          </div>
          <div>
            <InputLabel for="roles" value="نقش کاربری" />
            <select
              class="mt-1 border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm w-full"
              name="roles"
              v-model="form.roles"
            >
              <option v-for="item in props.roles" :value="item.id">
                {{ item.title }}
              </option>
            </select>
            <InputError class="mt-2" :message="form.errors.roles" />
          </div>
        </div>
        <div class="mt-4">
          <InputLabel for="package_name" value="پکیج نیم برنامه" />
          <TextInput
            id="package_name"
            name="package_name"
            type="text"
            class="mt-1 block w-full"
            v-model="form.package_name"
            autocomplete="package_name"
          />
          <InputError class="mt-2" :message="form.errors.package_name" />
        </div>
        <br />
        <hr />
        <div class="mt-4 pt-4">
          <InputLabel for="roles" value="قابلیت ها" />
          <div class="grid grid-cols-3 gap-4 mt-4">
            <div v-for="item in props.features" :value="item.id">
              <InputLabel for="title" :value="item.title" />
              <input
                id="link-checkbox"
                type="checkbox"
                :value="item.id"
                v-model="form.features"
                class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500"
              />
            </div>
          </div>
          <InputError class="mt-2" :message="form.errors.features" />
        </div>
        <div class="flex items-center justify-start mt-4">
          <PrimaryButton
            class="ml-4"
            :class="{ 'opacity-25': form.processing }"
            :disabled="form.processing"
          >
            ارسال
          </PrimaryButton>
        </div>
      </form>
    </div>
  </AuthenticatedLayout>
</template>
