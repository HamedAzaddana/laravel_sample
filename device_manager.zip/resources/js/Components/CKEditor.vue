<script setup>
import { onMounted, ref } from 'vue';
import * as editor from '@ckeditor/ckeditor5-build-classic';

const editor_data = ref('');
const editor_config = {};


defineProps({
    modelValue: {
        type: String,
        required: true,
    },
    editorConfig: {
        type: Object,
    },
});

defineEmits(['update:modelValue']);

const input = ref(null);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    <ckeditor
        class="w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
        v-model="modelValue"
        @input="$emit('update:modelValue', $event.target.value)"
        :editor="editor"
        :config="editorConfig"
    ></ckeditor>
</template>
