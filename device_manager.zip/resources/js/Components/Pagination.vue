<script setup>
import { Link } from "@inertiajs/vue3";
import { onBeforeMount, onMounted } from "vue";
import { get_query_param_url, set_query_param_url } from "@/Utils/helpers";

const props = defineProps({
  links: {
    type: Array,
  },
});
onBeforeMount(() => {
  const currentFullUrl = window.location.href;
  props.links.map((link) => {
    let pageNumberLink = get_query_param_url("page", link.url);
    let newLink = set_query_param_url(currentFullUrl, "page", pageNumberLink);
    link.url = newLink;
  });
});
</script>
<template>
  <div v-if="links.length > 3">
    <div class="flex flex-wrap -mb-1">
      <template v-for="(link, p) in links" :key="p">
        <div
          v-if="link.url === null"
          class="mr-1 mb-1 px-4 py-3 text-sm leading-4 text-gray-400 border rounded"
          v-html="link.label"
        />
        <Link
          v-else
          class="mr-1 mb-1 px-4 py-3 text-sm leading-4 border rounded hover:bg-white focus:border-indigo-500 focus:text-indigo-500"
          :class="{ 'bg-blue-700 text-white': link.active }"
          :href="link.url"
          v-html="link.label"
        />
      </template>
    </div>
  </div>
</template>
