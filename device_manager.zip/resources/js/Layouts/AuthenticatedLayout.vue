<script setup>
import { ref, onMounted } from "vue";
import ApplicationLogo from "@/Components/ApplicationLogo.vue";
import Dropdown from "@/Components/Dropdown.vue";
import DropdownLink from "@/Components/DropdownLink.vue";
import NavLink from "@/Components/NavLink.vue";
import ResponsiveNavLink from "@/Components/ResponsiveNavLink.vue";
import { Link } from "@inertiajs/vue3";
import "@/../css/extra.css";
import "@/../css/fontawesome_v4.css";
const showingNavigationDropdown = ref(false);

</script>

<template>
  <div class="min-h-screen bg-gray-100 pb-5">
    <nav class="bg-white border-b border-gray-100">
      <!-- Primary Navigation Menu -->
      <div class="mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
          <div class="flex">
            <!-- Logo -->
            <div class="shrink-0 flex items-center">
              <Link :href="route('dashboard')">
                <ApplicationLogo class="block h-9 w-auto fill-current text-gray-800" />
              </Link>
            </div>
            <!-- Navigation Links -->
            <div class="hidden sm:-my-px sm:ml-10 sm:flex">
              <NavLink
                class="mx-2"
                :href="route('dashboard')"
                :active="route().current('dashboard')"
              >
                داشبورد
              </NavLink>
              <NavLink
                v-if="$page.props.auth.roles.includes('admin')"
                class="mx-2"
                :href="route('users.index')"
                :active="route().current('users.index')"
              >
                کاربران
              </NavLink>
              <NavLink
                class="mx-2"
                :href="route('devices.index') + '?include=app'"
                :active="route().current('devices.index')"
              >
                لیست دستگاه ها
              </NavLink>
              <NavLink
                class="mx-2"
                :href="route('configs.index')"
                :active="route().current('configs.index')"
              >
                تنظیمات دستگاه ها
              </NavLink>
            </div>
          </div>

          <div class="hidden sm:flex sm:items-center sm:ml-6">
            <!-- Settings Dropdown -->
            <div class="ml-3 relative">
              <Dropdown align="left" width="48">
                <template #trigger>
                  <span class="inline-flex rounded-md">
                    <button
                      type="button"
                      class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150"
                    >
                      {{ $page.props.auth.user.name }}

                      <svg
                        class="ml-2 -mr-0.5 h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                          clip-rule="evenodd"
                        />
                      </svg>
                    </button>
                  </span>
                </template>

                <template #content>
                  <!--                                        <DropdownLink :href="route('profile.edit')"> Profile </DropdownLink>-->
                  <DropdownLink
                    :href="route('authentication.logout')"
                    method="post"
                    as="button"
                  >
                    خروج
                  </DropdownLink>
                </template>
              </Dropdown>
            </div>
          </div>

          <!-- Hamburger -->
          <div class="-mr-2 flex items-center sm:hidden">
            <button
              @click="showingNavigationDropdown = !showingNavigationDropdown"
              class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out"
            >
              <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                <path
                  :class="{
                    hidden: showingNavigationDropdown,
                    'inline-flex': !showingNavigationDropdown,
                  }"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16"
                />
                <path
                  :class="{
                    hidden: !showingNavigationDropdown,
                    'inline-flex': showingNavigationDropdown,
                  }"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <!-- Responsive Navigation Menu -->
      <div
        :class="{ block: showingNavigationDropdown, hidden: !showingNavigationDropdown }"
        class="sm:hidden"
      >
        <div class="pt-2 pb-3 space-y-1">
          <ResponsiveNavLink
            :href="route('dashboard')"
            :active="route().current('dashboard')"
          >
            داشبورد
          </ResponsiveNavLink>
          <ResponsiveNavLink
            :href="route('users.index')"
            :active="route().current('users.index')"
          >
            کاربران
          </ResponsiveNavLink>
          <ResponsiveNavLink
            :href="route('devices.index') + '?include=app'"
            :active="route().current('devices.index')"
          >
            لیست دستگاه ها
          </ResponsiveNavLink>
          <ResponsiveNavLink
            :href="route('configs.index')"
            :active="route().current('configs.index')"
          >
            تنظیمات دستگاه ها
          </ResponsiveNavLink>
        </div>

        <!-- Responsive Settings Options -->
        <div class="pt-4 pb-1 border-t border-gray-200">
          <div class="px-4">
            <div class="font-medium text-base text-gray-800">
              {{ $page.props.auth.user.name }}
            </div>
            <div class="font-medium text-sm text-gray-500">
              {{ $page.props.auth.user.username }}
            </div>
          </div>

          <div class="mt-3 space-y-1">
            <!--                            <ResponsiveNavLink :href="route('profile.edit')"> Profile </ResponsiveNavLink>-->
            <ResponsiveNavLink
              :href="route('authentication.logout')"
              method="post"
              as="button"
            >
              خروج
            </ResponsiveNavLink>
          </div>
        </div>
      </div>
    </nav>

    <!-- Page Heading -->
    <!--            <header class="bg-white shadow" v-if="$slots.header">-->
    <!--                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">-->
    <!--                    <slot name="header" />-->
    <!--                </div>-->
    <!--            </header>-->

    <!-- Page Content -->
    <main class="container mx-auto pt-4">
      <div
        v-if="$page.props.flash.message"
        class="bg-amber-100 border border-amber-400 text-amber-700 px-4 py-3 rounded relative mb-5 mt-1"
        role="alert"
      >
        <strong class="font-bold">{{ $page.props.flash.message }}</strong>
        <!--                <span class="block sm:inline">Something seriously bad happened.</span>-->
        <span
          @click="$page.props.flash.message = false"
          class="absolute top-0 bottom-0 left-0 px-4 py-3"
        >
          <svg
            class="fill-current h-6 w-6 text-amber-500"
            role="button"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <title>بستن</title>
            <path
              d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
            />
          </svg>
        </span>
      </div>
      <div
        v-if="$page.props.flash.success"
        class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-5 mt-1"
        role="alert"
      >
        <strong class="font-bold">{{ $page.props.flash.success }}</strong>
        <!--                <span class="block sm:inline">Something seriously bad happened.</span>-->
        <span
          @click="$page.props.flash.success = false"
          class="absolute top-0 bottom-0 left-0 px-4 py-3"
        >
          <svg
            class="fill-current h-6 w-6 text-green-500"
            role="button"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <title>بستن</title>
            <path
              d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
            />
          </svg>
        </span>
      </div>
      <div
        v-if="$page.props.flash.error"
        class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-5 mt-1"
        role="alert"
      >
        <strong class="font-bold">{{ $page.props.flash.error }}</strong>
        <!--                <span class="block sm:inline">Something seriously bad happened.</span>-->
        <span
          @click="$page.props.flash.error = false"
          class="absolute top-0 bottom-0 left-0 px-4 py-3"
        >
          <svg
            class="fill-current h-6 w-6 text-red-500"
            role="button"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <title>بستن</title>
            <path
              d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"
            />
          </svg>
        </span>
      </div>
      <!--            <h2 class="breadcrumbs">-->
      <!--                <Link v-for="link in $page.props.breadcrumbs" :href="link.path">{{link.title}} / </Link>-->
      <!--            </h2>-->
      <slot />
    </main>
  </div>
</template>
