
export function testJSON(text) {
    if (typeof text !== "string") {
        return false;
    }
    try {
        JSON.parse(text);
        return true;
    } catch (error) {
        return false;
    }
}
export function iterate_jsonify_data(object) {
    let new_obj = {};
    Object.keys(object).forEach(key => {
        let _val = object[key];
        if (typeof _val === 'object') {
            _val = JSON.stringify(_val);
        }
        new_obj[key] = _val;
    });
    return new_obj;

}

export function format_at_email_str(email) {
    return email.replace("@", ' [at] ')
}
export function get_query_param_url(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
export function set_query_param_url(uri, key, value) {
    var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
      return uri.replace(re, '$1' + key + "=" + value + '$2');
    }
    else {
      return uri + separator + key + "=" + value;
    }
}
export function convert_number_to_en(txt) {
    let _txt = new String(txt);
    _txt = _txt.replaceAll("۱", "1");
    _txt = _txt.replaceAll("۲", "2");
    _txt = _txt.replaceAll("۳", "3");
    _txt = _txt.replaceAll("۴", "4");
    _txt = _txt.replaceAll("۵", "5");
    _txt = _txt.replaceAll("۶", "6");
    _txt = _txt.replaceAll("۷", "7");
    _txt = _txt.replaceAll("۸", "8");
    _txt = _txt.replaceAll("۹", "9");
    _txt = _txt.replaceAll("۰", "0");
    return _txt;
}
export function convert_number_to_fa(txt) {
    let _txt = new String(txt);
    _txt = _txt.replaceAll("1", "۱");
    _txt = _txt.replaceAll("2", "۲");
    _txt = _txt.replaceAll("3", "۳");
    _txt = _txt.replaceAll("4", "۴");
    _txt = _txt.replaceAll("5", "۵");
    _txt = _txt.replaceAll("6", "۶");
    _txt = _txt.replaceAll("7", "۷");
    _txt = _txt.replaceAll("8", "۸");
    _txt = _txt.replaceAll("9", "۹");
    _txt = _txt.replaceAll("0", "۰");
    return _txt;
}
