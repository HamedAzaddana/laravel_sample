<?php

namespace Tests\Feature;

use App\Contracts\AppServiceInterface;
use App\Contracts\UserServiceInterface;
use App\Enums\FeatureEnum;
use App\Enums\RoleEnum;
use App\Models\App;
use App\Models\Feature;
use App\Models\Role;
use App\Models\User;
use Database\Factories\AppFactory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Inertia\Testing\AssertableInertia;
use Tests\TestCase;

class UserTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_create_user_model_test(): void
    {
        $data = User::factory()->definition();
        $user = User::create($data);
        $this->assertArrayHasKey('id', $user->toArray());
        $this->assertArrayHasKey('name', $user->toArray());
        $this->assertArrayHasKey('username', $user->toArray());
        $this->assertArrayNotHasKey('password', $user->toArray());
        $this->assertArrayHasKey('email', $user->toArray());
        $this->assertArrayHasKey('phone', $user->toArray());
        $this->assertDatabaseHas('users', [
            'name' => $data['name'],
            'username' => $data['username'],
            'password' => $data['password'],
            'email' => $data['email'],
            'phone' => $data['phone'],
        ]);
    }

    public function test_create_user_service_test(): void
    {
        $data = User::factory()->definition();
        $password = 'password';
        $packageName = 'test.app.com';
        $apps[] = app(AppServiceInterface::class)->create($packageName, $packageName)->id;
        $user = app(UserServiceInterface::class)->create($data['name'], $data['username'], $password, [2], $apps);
        $this->assertDatabaseHas('users', [
            'name' => $data['name'],
            'username' => $data['username'],
        ]);
        $this->assertDatabaseHas('apps', [
            'title' => $packageName,
            'package_name' => $packageName,
        ]);
        $this->assertArrayHasKey('id', $user->toArray());
        $this->assertArrayHasKey('name', $user->toArray());
        $this->assertArrayHasKey('username', $user->toArray());
        $this->assertArrayNotHasKey('password', $user->toArray());
    }


    public function test_create_user_web_form_test(): void
    {
        $user = User::factory()->definition();
        $role = Role::where('name', RoleEnum::admin)->first();
        $password = 'password';
        $packageName = 'test.app.com';
        $data['password'] = $password;
        $user = app(UserServiceInterface::class)->create($user['name'], $user['username'], $password, [$role->id]);
        $response = $this->actingAs($user)->json('GET', route('users.create'));
        $response->assertOk();
    }

    public function test_create_user_web_test(): void
    {
        $user = User::factory()->definition();
        $data = User::factory()->definition();
        $role = Role::where('name', RoleEnum::admin)->first();
        $password = 'password';
        $packageName = 'test.app.com';
        $data['password'] = $password;
        $data['package_name'] = $packageName;
        $user = app(UserServiceInterface::class)->create($user['name'], $user['username'], $password, [$role->id]);
        $response = $this->actingAs($user)->json('POST', route('users.store'), $data);
        $response->assertStatus(302)->assertSessionHas('success');
    }

    public function test_create_user_web_unauthenticated_test(): void
    {
        $response = $this->json('GET', route('users.create'));
        $response->assertStatus(401);
        $data = User::factory()->definition();
        $password = 'password';
        $packageName = 'test.app.com';
        $data['password'] = $password;
        $data['package_name'] = $packageName;
        $response = $this->json('POST', route('users.store'), $data);
        $response->assertStatus(401);
    }

    public function test_create_user_web_unauthorized_test(): void
    {
        $user = User::factory()->definition();
        $data = User::factory()->definition();
        $role = Role::where('name', RoleEnum::user)->first();
        $password = 'password';
        $packageName = 'test.app.com';
        $data['password'] = $password;
        $data['package_name'] = $packageName;
        $user = app(UserServiceInterface::class)->create($user['name'], $user['username'], $password, [$role->id]);
        $response = $this->actingAs($user)->json('GET', route('users.create'));
        $response->assertStatus(403);
        $response = $this->actingAs($user)->json('POST', route('users.store'), $data);
        $response->assertStatus(403);
    }

    public function test_create_user_web_request_validation_test(): void
    {
        $user = User::factory()->definition();
        $data = User::factory()->definition();
        $role = Role::where('name', RoleEnum::admin)->first();
        $password = 'password';
        $packageName = 'test.app.com';
        $data['password'] = $password;
        $data['package_name'] = $packageName;
        $user = app(UserServiceInterface::class)->create($user['name'], $user['username'], $password, [$role->id]);
        $response = $this->actingAs($user)->post(route('users.store'), []);
        $response->assertStatus(302)->assertSessionHasErrors(['name', 'username', 'password']);
    }

    public function test_create_user_web_request_validation_2_test(): void
    {
        $user = User::factory()->definition();
        $data = User::factory()->definition();
        $role = Role::where('name', RoleEnum::admin)->first();
        $password = 'password';
        $packageName = 'test.app com';
        $data['password'] = $password;
        $data['package_name'] = $packageName;
        $user = app(UserServiceInterface::class)->create($user['name'], $user['username'], $password, [$role->id]);
        $response = $this->actingAs($user)->post(route('users.store'), $data);
        $response->assertStatus(302)->assertSessionHasErrors(['package_name']);
    }
}
