<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Console\GeneratorCommand;

class MakeAction extends GeneratorCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:action {name}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
//    public function handle()
//    {
//        //
//    }

    public function getStub()
    {
        return app_path() . '/Console/Commands/Stubs/action.stub';
    }

    public function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace . '\Actions';
    }

//    public function replaceClass($stub, $name)
//    {
//        $stub = parent::replaceClass($stub, $name);
//
//        return str_replace("DummyAction", $this->argument('name'), $stub);
//    }
}
