<?php

namespace App\Http\Controllers\Web;

use App\Contracts\DeviceAuthenticationServiceInterface;
use App\Contracts\UserAuthenticationServiceInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AuthenticationRequest;
use App\Http\Requests\Api\SendVerificationCodeRequest;
use App\Http\Resources\UserResource;
use App\Services\UserAuthenticationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class AuthenticationController extends Controller
{
    public function __construct(readonly UserAuthenticationServiceInterface $authenticationService)
    {
    }

    public function authenticationPage()
    {
        return Inertia::render('Authentication/Authentication');
    }


    public function authentication(AuthenticationRequest $request)
    {
        try {
            $data = $this->authenticationService->authentication($request->username,$request->password);
            session('features',$data->features()?->pluck('key')?->toArray());
            return redirect()->route('dashboard');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('authentication.index');
    }
}
