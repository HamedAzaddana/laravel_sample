<?php

namespace App\Http\Controllers\Web;

use App\Contracts\AppServiceInterface;
use App\Contracts\ConfigServiceInterface;
use App\Contracts\DeviceAppServiceInterface;
use App\Contracts\DeviceLocationServiceInterface;
use App\Contracts\DeviceMessageServiceInterface;
use App\Contracts\DeviceServiceInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\Device\UpdateDeviceRequest;
use Illuminate\Http\Request;
use Inertia\Inertia;
use PhpMqtt\Client\Facades\MQTT;

class DeviceController extends Controller
{
    public function __construct(
        readonly DeviceServiceInterface $deviceService,
        readonly DeviceMessageServiceInterface $deviceMessageService,
        readonly DeviceAppServiceInterface $deviceAppService,
        readonly DeviceLocationServiceInterface $deviceLocationService,
        readonly AppServiceInterface $appService
    ) {}

    public function dd()
    {
        $mqtt = MQTT::connection();
        $mqtt->publish('123/config/change', '{dddddddd}', 1);
        //        $mqtt->loop(true, true);
        return '';
    }

    public function dd2()
    {
        $mqtt = MQTT::connection();
        $mqtt->subscribe('123/config/change', function (string $topic, string $message) {
            echo sprintf('Received QoS level 1 message on topic [%s]: %s', $topic, $message);
        }, 1);
        //        $mqtt->loop(true);
        return '';
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        $apps_all = $this->appService->index($request, false);
        $filters = $request->only(['device_app', 'device_title']);
        return Inertia::render('Device/Index', ['data' => $this->deviceService->index($request), 'defaultAppUserId' => auth()->user()->defaultAppUser()?->id, 'apps_all' => $apps_all, 'filters' => $filters]);
    }
    public function wipe_configs(Request $request, $id)
    {
        try {
            if (request()->confirmation) {
                return $this->wipe_configs_force($request,$id);
            }
            $msg="آیا برای حذف تنظیمات این دستگاه مطمئن هستید ؟";
            return redirect()->back()->with('confirm_swal', [
                'message' => $msg,
                'data' => [
                    'id'=>$id
                ],
            ]);
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }
    public function wipe_configs_force(Request $request, $id)
    {
        $this->deviceService->wipe_configs($id);
        return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
    }
    /**
     * Display a listing of the resource.
     */
    public function appsIndex(Request $request)
    {
        return Inertia::render('Device/Apps', ['data' => $this->deviceAppService->index($request->device_id, $request, true), 'device_id' => $request->device_id]);
    }

    /**
     * Display a listing of the resource.
     */
    public function appsCreate(Request $request)
    {
        return Inertia::render('Device/AppsForm', ['device_id' => $request->device_id]);
    }

    public function appsStore(Request $request)
    {
        try {
            $device = $this->deviceAppService->create($request->device_id, $request->package_name, $request->file, $request->title);
            return redirect()->route('devices.apps.index', ['device_id' => $request->device_id])->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    public function appsDelete(Request $request)
    {
        try {
            $device = $this->deviceAppService->delete($request->id);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    public function appsChangeStatus(Request $request)
    {
        try {
            $device = $this->deviceAppService->changeStatus($request->id, $request->status);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function locations(Request $request)
    {
        $filters = [];
        if (preg_match('/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/', $request->date_filter)) {
            $filters['date_filter'] =  $request->date_filter;
        } else {
            $filters['date_filter'] = jdate()->format("Y/m/d");
        }
        $data = $this->deviceLocationService->indexMerged($request->device_id, $filters);
        $today = jdate()->format("Y/m/d");
        return Inertia::render('Device/Locations', ['data' => $data, 'today' => $today, 'filters' => $filters]);
    }
    public function tracker(Request $request)
    {
        return Inertia::render('Device/Tracker');
    }
    /**
     * Display a listing of the resource.
     */
    public function messages(Request $request)
    {
        $data = $this->deviceMessageService->index($request->device_id, $request);
        return Inertia::render('Device/Messages', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        return Inertia::render('Device/Form', ['data' => [], 'apps' => $this->appService->index($request, false)]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $device = $this->deviceService->createByRequest($request);
            return redirect()->route('devices.index')->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id, Request $request)
    {
        $data = $this->deviceService->find($id);
        return Inertia::render('Device/Form', ['data' => $data, 'apps' => $this->appService->index($request, false)]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDeviceRequest $request, string $id)
    {
        try {
            $device = $this->deviceService->updateByRequest($request);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete(string $id)
    {
        try {
            $device = $this->deviceService->delete($id);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }
}
