<?php

namespace App\Http\Controllers\Web;

use App\Contracts\AppServiceInterface;
use App\Contracts\ConfigServiceInterface;
use App\Contracts\DeviceServiceInterface;
use App\Contracts\FeatureServiceInterface;
use App\Enums\ConfigTypeEnum;
use App\Enums\FeatureTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\Config\StoreConfigRequest;
use App\Http\Requests\Web\Config\UpdateConfigRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ConfigController extends Controller
{
    public function __construct(readonly ConfigServiceInterface $configService, readonly FeatureServiceInterface $featureService, readonly DeviceServiceInterface $deviceService, readonly AppServiceInterface $appService) {}

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        return Inertia::render('Config/Index', ['data' => $this->configService->index($request)]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        return Inertia::render('Config/Form', ['data' => [], 'defaultAppUserId' => auth()->user()->defaultAppUser()?->id, 'devices' => $this->deviceService->index($request, false), 'apps' => $this->appService->index($request, false), 'types' => ConfigTypeEnum::transform(), 'features' => $this->featureService->index($request, false)]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreConfigRequest $request)
    {
        try {
            $config = $this->configService->createByRequest($request);
            return redirect()->route("configs.create", ['refresh' => true])->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id, Request $request)
    {
        return Inertia::render('Config/Form', ['data' => $this->configService->find($id), 'defaultAppUserId' => auth()->user()->defaultAppUser()?->id, 'devices' => $this->deviceService->index($request, false), 'apps' => $this->appService->index($request, false), 'types' => ConfigTypeEnum::transform(), 'features' => $this->featureService->index($request, false)]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateConfigRequest $request, string $id)
    {
        try {
            $config = $this->configService->updateByRequest($request);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete(string $id)
    {
        try {
            if (request()->confirmation) {
                return $this->deleteForce($id);
            }
            $messages = $this->configService->preProcessDelete($id);
            if (!$messages) {
                return $this->deleteForce($id);
            } else {
                return redirect()->back()->with('confirm_swal', [
                    'message' => $messages,
                    'data' => [
                        'id'=>$id
                    ],
                ]);
            }
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }
    private function deleteForce(string $id)
    {
        $config = $this->configService->delete($id);
        return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
    }
}
