<?php

namespace App\Http\Controllers\Web;

use App\Contracts\FeatureServiceInterface;
use App\Contracts\UserServiceInterface;
use App\Exports\UsersExport;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\User\CreateUserRequest;
use App\Http\Requests\Web\User\EditUserRequest;
use App\Http\Requests\Web\User\IndexUserRequest;
use App\Http\Requests\Web\User\StoreUserRequest;
use App\Http\Requests\Web\User\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use Maatwebsite\Excel\Facades\Excel;

class UserController extends Controller
{
    public function __construct(readonly UserServiceInterface $userService, readonly FeatureServiceInterface $featureService)
    {
    }

    public function create(CreateUserRequest $request)
    {
        return Inertia::render('User/Form', ['roles' => Role::all(), 'features' => $this->featureService->index($request, false), 'data' => []]);
    }

    public function store(StoreUserRequest $request)
    {
        try {
            $user = $this->userService->createByRequest($request);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    public function edit(EditUserRequest $request)
    {
        return Inertia::render('User/Form', ['roles' => Role::all(), 'features' => $this->featureService->index($request, false), 'data' => $this->userService->find($request->id)->load(['roles', 'apps','apps.features'])]);
    }

    public function update(UpdateUserRequest $request)
    {
        try {
            $user = $this->userService->updateByRequest($request);
            return redirect()->back()->with('success', 'عملیات با موفقیت انجام شد.');
        } catch (\Exception $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }
    }

    public function index(IndexUserRequest $request)
    {
        $users = $this->userService->index($request);
        return Inertia::render('User/Index', ['users' => $users]);
    }

    public function export(IndexUserRequest $request)
    {
        return Excel::download(new UsersExport($request), 'users_export.xlsx');
    }

}
