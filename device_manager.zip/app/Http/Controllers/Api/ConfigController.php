<?php

namespace App\Http\Controllers\Api;

use App\Contracts\ConfigServiceInterface;
use App\Contracts\DeviceServiceInterface;
use App\Enums\DeviceConfigStatusEnum;
use App\Enums\SyncTypeEnum;
use App\Exceptions\NotFoundResourceException;
use App\Http\Controllers\Controller;
use App\Http\Resources\ConfigResource;
use App\Http\Resources\DeviceAppResource;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;

class ConfigController extends Controller
{
    public function __construct(readonly ConfigServiceInterface $configService)
    {
    }

    public function find(Request $request)
    {
        try {
            $data = $this->configService->find($request->id);
            $this->configService->changeDeviceConfigStatus(auth()->id(), $request->id, DeviceConfigStatusEnum::received);
            return new ConfigResource($data);
        } catch (\Exception $exception) {
            throw new NotFoundResourceException();
        }
    }
}
