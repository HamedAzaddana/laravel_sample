<?php

namespace App\Http\Controllers\Api;

use App\Contracts\ConfigServiceInterface;
use App\Contracts\DeviceAuthenticationServiceInterface;
use App\Contracts\DeviceServiceInterface;
use App\Enums\SyncTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Resources\ConfigResource;
use App\Http\Resources\DeviceAppResource;
use App\Http\Resources\DeviceFeaturesResource;
use App\Http\Resources\UserResource;
use App\Models\AppFeature;
use App\Models\Feature;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    public function __construct(
        readonly DeviceServiceInterface $deviceService,
        readonly ConfigServiceInterface $configService,
        readonly DeviceAuthenticationServiceInterface $authenticationService
    ) {}

    public function sync(Request $request)
    {
        try {
            $data = $this->deviceService->sync($request);
            $type = $request->type ?? SyncTypeEnum::apps;
            if ($type != SyncTypeEnum::apps) {
                //                $configs = $this->configService->findByDeviceId($data->app->id, $data->id);
                return $this->json();
            } else {
                return DeviceAppResource::collection($data);
            }
        } catch (\Exception $exception) {
            return $this->json();
        }
    }
    public function getFeatures(Request $request)
    {
        $deviceAppId = $this->authenticationService->getAuthenticatedDevice()->app_id;
        $featureIds = AppFeature::where('app_id', $deviceAppId)->get()->pluck('feature_id')->toArray();
        $features = Feature::whereIn('id', $featureIds)->select("key", "title")->get()->toArray();
        return $this->json($features);
    }
}
