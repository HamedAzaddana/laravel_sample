<?php

namespace App\Http\Controllers\Api;

use App\Contracts\DeviceAuthenticationServiceInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AuthenticationRequest;
use App\Http\Requests\Api\SendVerificationCodeRequest;
use App\Http\Resources\DeviceResource;
use App\Http\Resources\UserResource;
use Illuminate\Http\Request;

class AuthenticationController extends Controller
{
    public function __construct(readonly DeviceAuthenticationServiceInterface $authenticationService)
    {
    }


    public function authentication(AuthenticationRequest $request)
    {
        try {
            $token = !empty($request->token) ? $request->token : $request->header('token');
            $packageName = !empty($request->package_name) ? $request->package_name : $request->header('package_name');
            $data = $this->authenticationService->authentication($token,$packageName);
            return new DeviceResource($data);
        } catch (\Exception $exception) {
            throw $exception;
        }
    }

    public function getAuthenticatedDevice(Request $request)
    {
        try {
            $user = $this->authenticationService->getAuthenticatedDevice();
            return new DeviceResource($user);
        } catch (\Exception $exception) {
            throw $exception;
        }
    }


}
