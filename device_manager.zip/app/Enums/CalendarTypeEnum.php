<?php

namespace App\Enums;

use App\Traits\EnumTrait;
use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

class CalendarTypeEnum extends Enum implements LocalizedEnum
{
    use EnumTrait;
    const jalali='jalali';
    const gregorian='gregorian';
}
