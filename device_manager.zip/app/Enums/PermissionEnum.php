<?php declare(strict_types=1);

namespace App\Enums;

use App\Traits\EnumTrait;
use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class PermissionEnum extends Enum implements LocalizedEnum
{
    use EnumTrait;
    const manage_users = 'manage_users';
    const manage_devices = 'manage_devices';

}
