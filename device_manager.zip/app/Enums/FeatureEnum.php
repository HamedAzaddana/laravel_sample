<?php declare(strict_types=1);

namespace App\Enums;

use App\Traits\EnumTrait;
use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class FeatureEnum extends Enum implements LocalizedEnum
{
    use EnumTrait;
    const i0 = 'i0';
    const i1 = 'i1';
    const i2 = 'i2';
    const i3 = 'i3';
    const i4 = 'i4';
    const i5 = 'i5';
    const i6 = 'i6';
    const i7 = 'i7';
    const i8 = 'i8';
    const i9 = 'i9';
    const l1 = 'l1';
    const l2 = 'l2';
    const l3 = 'l3';
    const l4 = 'l4';
    const l5 = 'l5';
    const l6 = 'l6';
    const l7 = 'l7';
    const l8 = 'l8';
    const l9 = 'l9';
    const us = 'us';
    const pa = 'pa';
//    const ki = 'ki';
//    const ap = 'ap';

}
