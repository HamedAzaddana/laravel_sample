<?php declare(strict_types=1);

namespace App\Enums;

use App\Traits\EnumTrait;
use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class RoleEnum extends Enum implements LocalizedEnum
{
    use EnumTrait;
    const admin = 'admin';
    const user = 'user';

}
