<?php

namespace App\Exports;

use App\Contracts\UserServiceInterface;
use App\Models\User;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

class UsersExport implements FromCollection, WithHeadings, WithColumnWidths, WithColumnFormatting, WithMapping
{
    public function __construct(public Request $request)
    {
    }

    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return app(UserServiceInterface::class)->index($this->request);
    }

    public function columnWidths(): array
    {
        return [
            'A' => 40,
            'B' => 40,
            'D' => 40,
            'E' => 40,
            'F' => 40,
            'G' => 40,
            'H' => 40,
        ];
    }

    public function headings(): array
    {
        return [
            'نام و نام خانوادگی',
            'نام کاربری',
            'پکیج نیم',
        ];
    }

    public function columnFormats(): array
    {
        return [
            'B' => NumberFormat::FORMAT_NUMBER,
        ];
    }

    public function map($row): array
    {
        return [
            $row->name,
            $row->username,
            $row->app()?->package_name,
        ];
    }
}

