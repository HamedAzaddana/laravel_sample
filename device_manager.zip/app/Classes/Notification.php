<?php

namespace App\Classes;

use App\Contracts\NotificationInterface;

class Notification
{
    public static function send(NotificationInterface $notification): void
    {
        $notification->send();
    }
}
