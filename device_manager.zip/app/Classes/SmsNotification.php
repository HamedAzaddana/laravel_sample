<?php

namespace App\Classes;

use App\Contracts\NotificationInterface;
use App\Jobs\SendMessageBySmsJob;
use App\Jobs\SendVerificationCodeBySmsJob;

class SmsNotification implements NotificationInterface
{
    public function __construct(readonly string $phone, readonly string $message)
    {
    }

    public function send(): void
    {
        // TODO: Implement send() method.
        dispatch(new SendMessageBySmsJob($this->phone, $this->message));
    }
}
