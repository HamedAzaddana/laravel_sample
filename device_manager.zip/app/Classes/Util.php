<?php

namespace App\Classes;

use App\Models\Category;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\Section;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;


class Util
{
    private static $instances = [];

    /**
     * The Singleton's constructor should always be private to prevent direct
     * construction calls with the `new` operator.
     */
    protected function __construct()
    {
    }

    /**
     * Singletons should not be cloneable.
     */
    protected function __clone()
    {
    }

    /**
     * Singletons should not be restorable from strings.
     */
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize a singleton.");
    }

    public static function getInstance(): Util
    {
        $cls = static::class;
        if (!isset(self::$instances[$cls])) {
            self::$instances[$cls] = new static();
        }

        return self::$instances[$cls];
    }

    public static function textNormalization($text)
    {
        $text = str_replace('ي', 'ی', $text);
        $text = str_replace('ي', 'ی', $text);
        $text = str_replace('ي', 'ی', $text);
        $text = str_replace('ي', 'ی', $text);
        $text = str_replace('ك', 'ک', $text);
        $text = str_replace('ک', 'ک', $text);
        $text = str_replace('ۀ', 'ه', $text);
        $text = str_replace('ة', 'ه', $text);
        $text = str_replace('  ', ' ', $text);
        $text = str_replace('  ', ' ', $text);
        $text = trim($text);
        return $text;
    }

    public static function textSimplization($text, $space = '')
    {
        $text = self::textNormalization($text);
        $text = str_replace('\'', '', $text);
        $text = str_replace('"', '', $text);
        $text = str_replace('`', '', $text);
        $text = str_replace('~', '', $text);
        $text = str_replace('?', '', $text);
        $text = str_replace('؟', '', $text);
        $text = str_replace('^', '', $text);
        $text = str_replace('%', '', $text);
        $text = str_replace('$', '', $text);
        $text = str_replace('#', '', $text);
        $text = str_replace('@', '', $text);
        $text = str_replace('!', '', $text);
        $text = str_replace('/', '', $text);
        $text = str_replace('-', '', $text);
        $text = str_replace('+', '', $text);
        $text = str_replace(';', '', $text);
        $text = str_replace(':', '', $text);
        $text = str_replace('>', '', $text);
        $text = str_replace('<', '', $text);
        $text = str_replace('ء', '', $text);
        $text = str_replace('&', '', $text);
        $text = str_replace('(', '', $text);
        $text = str_replace(')', '', $text);
        $text = str_replace('{', '', $text);
        $text = str_replace('}', '', $text);
        $text = str_replace('[', '', $text);
        $text = str_replace(']', '', $text);
        $text = str_replace('\\', '', $text);
        $text = str_replace('|', '', $text);
        $text = str_replace('.', '', $text);
        $text = str_replace('َ', '', $text);
        $text = str_replace('ُ', '', $text);
        $text = str_replace('ِ', '', $text);
        $text = str_replace('ّ', '', $text);
        $text = str_replace('_', '', $text);
        $text = str_replace('«', '', $text);
        $text = str_replace('»', '', $text);
        $text = str_replace('ً', '', $text);
        $text = str_replace('ٌ', '', $text);
        $text = str_replace('ٍ', '', $text);
        $text = str_replace('،', '', $text);
        $text = str_replace('؛', '', $text);
        $text = str_replace(',', '', $text);
        $text = str_replace('’', '', $text);
        $text = str_replace('_', '', $text);
        $text = str_replace(',', '', $text);
        $text = str_replace(' ', $space, $text);
        $text = trim($text);
        return $text;
    }

    public static function twoNum($string)
    {
        if (strlen($string) < 2)
            return '0' . $string;
        else
            return $string;
    }

    public static function convertToEn($string)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabic = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١', '٠'];

        $num = range(0, 9);
        $convertedPersianNums = str_replace($persian, $num, $string);
        $englishNumbersOnly = str_replace($arabic, $num, $convertedPersianNums);

        return $englishNumbersOnly;
    }

    public static function fileStore($file, $path, $driver = 'public'): string
    {
        if (!empty($file)) {
            $fileHash = str_replace('.' . $file->extension(), '', $file->hashName());
//            $fileHash = Carbon::now()->getTimestampMs() . '' . rand(1000, 9999);
            $fileName = $fileHash . '.' . $file->getClientOriginalExtension();
            if ($path = $file->storeAs($path, $fileName, $driver)) {
                return $path;
            } else {
                throw new \Exception('file not uploaded');
            }
        } else {
            throw new \Exception('file not uploaded');
        }
    }

    public static function fileDelete($path): bool
    {
        if (!empty($path)) {
            return Storage::drive('public')->delete($path);
        } else {
            return false;
        }
    }

    public static function isVerificationCodeTrue($phone, $code)
    {
        return Cache::get('phone_verification_code_' . $phone) == $code;
    }

    public static function getRandomNumber($min = 1000, $max = 9999)
    {
        return mt_rand($min, $max);
    }

    public static function sendVerificationCodeBySms($phone, $code)
    {
        $api = new \Kavenegar\KavenegarApi(config('kavenegar.apikey'));
        $api->VerifyLookup($phone, $code, null, null, 'titimeConfirmation');
    }

    public static function sendMessageBySms($phone, $message)
    {
        $api = new \Kavenegar\KavenegarApi(config('kavenegar.apikey'));
        $api->send('10000700700600',$phone, $message);
    }

    public static function getDayNames($day, $shorten = false, $len = 1, $numeric = false)
    {
        switch (strtolower($day)) {
            case 'sat':
            case 'saturday':
            case 1:
                $ret = 'شنبه';
                $n = 1;
                break;
            case 'sun':
            case 'sunday':
            case 2:
                $ret = 'یکشنبه';
                $n = 2;
                break;
            case 'mon':
            case 'monday':
            case 3:
                $ret = 'دوشنبه';
                $n = 3;
                break;
            case 'tue':
            case 'tuesday':
            case 4:
                $ret = 'سه شنبه';
                $n = 4;
                break;
            case 'wed':
            case 'wednesday':
            case 5:
                $ret = 'چهارشنبه';
                $n = 5;
                break;
            case 'thu':
            case 'thursday':
            case 6:
                $ret = 'پنجشنبه';
                $n = 6;
                break;
            case 'fri':
            case 'friday':
            case 7:
                $ret = 'جمعه';
                $n = 7;
                break;
            default:
                $ret = '';
                $n = -1;
        }

        return ($numeric) ? $n : (($shorten) ? mb_substr($ret, 0, $len, 'UTF-8') : $ret);
    }

    public static function getDayMNames($day)
    {
        switch (strtolower($day)) {
            case 1:
                $ret = 'یکم';
                break;
            case 2:
                $ret = 'دوم';
                break;
            case 3:
                $ret = 'سوم';
                break;
            case 4:
                $ret = 'چهارم';
                break;
            case 5:
                $ret = 'پنجم';
                break;
            case 6:
                $ret = 'ششم';
                break;
            case 7:
                $ret = 'هفتم';
                break;
            case 8:
                $ret = 'هشتم';
                break;
            case 9:
                $ret = 'نهم';
                break;
            case 10:
                $ret = 'دهم';
                break;
            case 11:
                $ret = 'یازدهم';
                break;
            case 12:
                $ret = 'دوازدهم';
                break;
            case 13:
                $ret = 'سیزدهم';
                break;
            case 14:
                $ret = 'چهاردهم';
                break;
            case 15:
                $ret = 'پانزدهم';
                break;
            case 16:
                $ret = 'شانزدهم';
                break;
            case 17:
                $ret = 'هفدهم';
                break;
            case 18:
                $ret = 'هجدهم';
                break;
            case 19:
                $ret = 'نوزدهم';
                break;
            case 20:
                $ret = 'بیستم';
                break;
            case 21:
                $ret = 'بیست و یکم';
                break;
            case 22:
                $ret = 'بیست و دوم';
                break;
            case 23:
                $ret = 'بیست و سوم';
                break;
            case 24:
                $ret = 'بیست و چهارم';
                break;
            case 25:
                $ret = 'بیست و پنجم';
                break;
            case 26:
                $ret = 'بیست و ششم';
                break;
            case 27:
                $ret = 'بیست و هفتم';
                break;
            case 28:
                $ret = 'بیست و هشتم';
                break;
            case 29:
                $ret = 'بیست و نهم';
                break;
            case 30:
                $ret = 'سی ام';
                break;
            case 31:
                $ret = 'سی و یکم';
                break;
            default:
                $ret = '';
        }
        return $ret;
    }


    public static function toJalali($date, $showTime = false, $sep = '-')
    {
        try {
            $date = self::convertToEn($date);
            $time = date('H:i:s');
            $date = explode(' ', $date);
            if (count($date) > 1) {
                $time = $date[1];
            }
//                if (strlen($date) > 10) {
//                    $date = substr($date, 0, 10);
//                }
//                $date = substr($date, 0, 10);
            $date = $date[0];
            if (strpos($date, '/') !== false) {
                $date = explode('/', $date);
                $date = \Morilog\Jalali\CalendarUtils::toJalali($date[0], self::twoNum($date[1]), self::twoNum($date[2]));
            } else {
                $date = explode('-', $date);
                $date = \Morilog\Jalali\CalendarUtils::toJalali($date[0], self::twoNum($date[1]), self::twoNum($date[2]));
            }
            if ($showTime && $time != '') {
                return $date[0] . $sep . self::twoNum($date[1]) . $sep . self::twoNum($date[2]) . ' ' . date('H:i:s', strtotime($time));
            } else {
                return $date[0] . $sep . self::twoNum($date[1]) . $sep . self::twoNum($date[2]);
            }
        } catch (\Exception $e) {
            return '';
        }
    }
    public static function timestampToDate($value, $timezone = 'Asia/Tehran', $format = 'Y-m-d H:i:s'): string|null
    {
        if (!empty($value) && is_numeric($value)) {
            $value = Carbon::createFromTimestampMs($value, $timezone);
            $value = $value->toDateTime()->format($format);
        }
        return $value;
    }
    public static function toGregorian($date, $showTime = false, $sep = '-')
    {
        if (!empty(trim($date))) {
            try {
                $date = self::convertToEn($date);
//      $time = date('H:i:s');
                $time = '23:59:59';
                $date = explode(' ', $date);
                if (count($date) > 1) {
                    $time = $date[1];
                }
//                if (strlen($date) > 10) {
//                    $date = substr($date, 0, 10);
//                }
//                $date = substr($date, 0, 10);
                $date = $date[0];
                if (strpos($date, '/') !== false) {
                    $date = explode('/', $date);
                    $date = \Morilog\Jalali\CalendarUtils::toGregorian($date[0], self::twoNum($date[1]), self::twoNum($date[2]));
                } else {
                    $date = explode('-', $date);
                    $date = \Morilog\Jalali\CalendarUtils::toGregorian($date[0], self::twoNum($date[1]), self::twoNum($date[2]));
                }
                if ($showTime && $time != '') {
                    return $date[0] . $sep . self::twoNum($date[1]) . $sep . self::twoNum($date[2]) . ' ' . date('H:i:s', strtotime($time));
                } else {
                    return $date[0] . $sep . self::twoNum($date[1]) . $sep . self::twoNum($date[2]);
                }
            } catch (\Exception $e) {
                return '';
            }
        } else {
            return '';
        }
    }

    public static function getUploadPath($path): string
    {
        $path .= '/' . Carbon::now()->year . '/' . Carbon::now()->month;
        return $path;
    }

    public static function getModelType(string $modelType)
    {
        if (str_contains($modelType, 'App\Models')) return $modelType;
        return 'App\Models\\' . Str::ucfirst($modelType);
    }

    public static function breadcrumbs(): array
    {
        $routeName = request()->route()->getName();
        $path = [];
        if ($routeName == 'courses.index' || $routeName == 'courses.create') {
            $path[] = ['title' => 'دوره ها', 'path' => route($routeName)];
        } elseif ($routeName == 'courses.edit') {
            $data = Course::find(request('id'));
            $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
            $path[] = ['title' => $data->title, 'path' => route($routeName, [$data->id])];
        } elseif ($routeName == 'categories.index' || $routeName == 'categories.create') {
            $path[] = ['title' => 'دسته بندی ها', 'path' => route($routeName)];
        } elseif ($routeName == 'categories.edit') {
            $data = Category::find(request('id'));
            $path[] = ['title' => 'دسته بندی ها', 'path' => route('categories.index')];
            $path[] = ['title' => $data->title, 'path' => route($routeName, [$data->id])];
        } elseif ($routeName == 'users.index' || $routeName == 'users.create') {
            $path[] = ['title' => 'کاربران', 'path' => route($routeName)];
        } elseif ($routeName == 'users.edit') {
            $data = User::find(request('id'));
            $path[] = ['title' => 'کاربران', 'path' => route('users.index')];
            $path[] = ['title' => $data->first_name . ' ' . $data->last_name, 'path' => route($routeName, [$data->id])];
        } elseif ($routeName == 'sections.index' || $routeName == 'sections.create') {
            $data = app(Util::getModelType(request('model_type')))->find(request('model_id'));
            if (request('model_type') == 'course' || request('model_type') == 'App\Models\Course' ) {
                $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
                $path[] = ['title' => $data->title, 'path' => route('courses.edit', [request('model_id')])];
                $path[] = ['title' => 'معرفی', 'path' => route($routeName, [request('model_type'), request('model_id')])];
            } elseif (request('model_type') == 'lesson' || request('model_type') == 'App\Models\Lesson') {
                $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
                $path[] = ['title' => $data->course->title, 'path' => route('courses.edit', [$data->course->id])];
                $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->course->id])];
                $path[] = ['title' => $data->parent->title, 'path' => route('seasons.edit', [$data->parent->id])];
                $path[] = ['title' => 'درس ها', 'path' => route('lessons.index', [$data->parent->id])];
                $path[] = ['title' => $data->title, 'path' => route('lessons.edit', [$data->id])];
                $path[] = ['title' => 'بخش ها', 'path' => route('sections.index', [request('model_type'), request('model_id')])];
            }
        }elseif ($routeName == 'sections.edit') {
            $section=Section::find(request('id'));
            $data = app(Util::getModelType($section->model_type))->find($section->model_id);
            if ($section->model_type == 'App\Models\Course') {
                $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
                $path[] = ['title' => $data->title, 'path' => route('courses.edit', [$section->model_id])];
                $path[] = ['title' => 'معرفی', 'path' => route('sections.index', [$section->model_type,$section->model_id])];
                $path[] = ['title' => $section->title, 'path' => route($routeName, [$section->id])];
            } elseif ($section->model_type == 'App\Models\Lesson') {
                $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
                $path[] = ['title' => $data->course->title, 'path' => route('courses.edit', [$data->course->id])];
                $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->course->id])];
                $path[] = ['title' => $data->parent->title, 'path' => route('seasons.edit', [$data->parent->id])];
                $path[] = ['title' => 'درس ها', 'path' => route('lessons.index', [$data->parent->id])];
                $path[] = ['title' => $data->title, 'path' => route('lessons.edit', [$data->id])];
                $path[] = ['title' => 'بخش ها', 'path' => route('sections.index', [$section->model_type,$section->model_id])];
                $path[] = ['title' => $section->title, 'path' => route($routeName, [$section->id])];
            }
        } elseif ($routeName == 'seasons.index' || $routeName == 'seasons.create') {
            $data = Course::find(request('course_id'));
            $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
            $path[] = ['title' => $data->title, 'path' => route('courses.edit', [$data->id])];
            $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->id])];
        }elseif ($routeName == 'seasons.edit') {
            $data = Lesson::find(request('id'));
            $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
            $path[] = ['title' => $data->course->title, 'path' => route('courses.edit', [$data->course->id])];
            $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->course->id])];
            $path[] = ['title' => $data->title, 'path' => route('seasons.edit', [$data->id])];
        }elseif ($routeName == 'lessons.index' || $routeName == 'lessons.create') {
            $data = Lesson::find(request('parent_id'));
            $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
            $path[] = ['title' => $data->course->title, 'path' => route('courses.edit', [$data->course->id])];
            $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->course->id])];
            $path[] = ['title' => $data->title, 'path' => route('seasons.edit', [$data->id])];
            $path[] = ['title' => 'درس ها', 'path' => route('lessons.index', [$data->id])];
        }elseif ($routeName == 'lessons.edit') {
            $data = Lesson::find(request('id'));
            $path[] = ['title' => 'دوره ها', 'path' => route('courses.index')];
            $path[] = ['title' => $data->course->title, 'path' => route('courses.edit', [$data->course->id])];
            $path[] = ['title' => 'فصل ها', 'path' => route('seasons.index', [$data->course->id])];
            $path[] = ['title' => $data->parent->title, 'path' => route('seasons.edit', [$data->parent->id])];
            $path[] = ['title' => 'درس ها', 'path' => route('lessons.index', [$data->parent->id])];
            $path[] = ['title' => $data->title, 'path' => route('lessons.edit', [$data->id])];
        }

        return $path;
    }
}
