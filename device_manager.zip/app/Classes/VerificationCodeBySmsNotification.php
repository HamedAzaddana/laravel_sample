<?php

namespace App\Classes;

use App\Contracts\NotificationInterface;
use App\Jobs\SendVerificationCodeBySmsJob;

class VerificationCodeBySmsNotification implements NotificationInterface
{
    public function __construct(readonly string $phone, readonly string $verificationCode)
    {
    }

    public function send(): void
    {
        dispatch(new SendVerificationCodeBySmsJob($this->phone, $this->verificationCode));
    }
}
