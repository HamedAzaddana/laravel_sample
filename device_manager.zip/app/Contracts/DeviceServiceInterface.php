<?php

namespace App\Contracts;

use App\Models\Config;
use App\Models\Device;
use App\Models\DeviceApp;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface DeviceServiceInterface
{
    function createByRequest(Request $request): Device;

    function updateByRequest(Request $request): Device;

    function sync(Request $request);

    function create(string $token, int $appId, string|null $fcmToken = null, string|null $number = null, string|null $title = null, string|null $device = null, string|null $product = null, string|null $model = null, string|null $manufacturer = null, string|null $androidVersion = null, string|null $androidApi = null, string|null $batteryLevel = null): Device;

    function update(int $id, string $token, int $appId, string|null $fcmToken, string|null $number = null, string|null $title = null, string|null $device = null, string|null $product = null, string|null $model = null, string|null $manufacturer = null, string|null $androidVersion = null, string|null $androidApi = null, string|null $batteryLevel = null): Device;

    function find(int $id): Device;

    function delete(int $id): bool;

    function wipe_configs(int $id): void;

    function findByToken(string $token): Device;

    function configs(int $id): Collection;

    function getByAppId(int $appId, bool $paginate = true): Collection|LengthAwarePaginator;

    function index(Request $request, bool $paginate = true): Collection|LengthAwarePaginator;
    

    function getPendingConfigs(int $id): Collection;

}
