<?php

namespace App\Contracts;

use App\Models\Device;
use App\Models\User;
use Illuminate\Auth\AuthenticationException;

interface DeviceAuthenticationServiceInterface
{
    function authentication(string $token, string $packageName): Device;

    function getAuthenticatedDevice(): Device;

}
