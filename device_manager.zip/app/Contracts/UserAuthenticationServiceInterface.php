<?php

namespace App\Contracts;

use App\Models\User;
use Illuminate\Auth\AuthenticationException;

interface UserAuthenticationServiceInterface
{
    function authentication(string $username, string $password): User;

    function getAuthenticatedUser(): User;


}
