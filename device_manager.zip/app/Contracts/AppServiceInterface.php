<?php

namespace App\Contracts;

use App\Models\App;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface AppServiceInterface
{
    function createByRequest(Request $request): App;

    function updateByRequest(Request $request): App;

    function create(string $title, string $packageName, array $features = []): App;

    function update(int $id, string $title, string $packageName, array $features = []): App;

    function find(int $id): App;

    function findByPackageName(string $packageName): App;

    function delete(int $id): bool;

    public function index(Request $request, bool $paginate = true): Collection|LengthAwarePaginator;
}
