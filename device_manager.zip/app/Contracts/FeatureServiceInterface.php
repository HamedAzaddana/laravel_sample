<?php

namespace App\Contracts;

use App\Models\Feature;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface FeatureServiceInterface
{
    function createByRequest(Request $request):Feature;
    function updateByRequest(Request $request):Feature;
    function create(string $title, string $key): Feature;

    function update(int $id, string $title, string $key): Feature;

    function find(int $id): Feature;

    function delete(int $id): bool;

    public function index(Request $request, bool $paginate = true): Collection|LengthAwarePaginator;
}
