<?php

namespace App\Contracts;

use App\Models\Config;
use App\Models\Device;
use App\Models\DeviceApp;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface DeviceAppServiceInterface
{
    function sync(int $deviceId, array $apps);

    function delete(int $id): bool;

    function create(int $deviceId, string $packageName, $file, string|null $title = null): DeviceApp;

    function changeStatus(int $id, string $status): DeviceApp;

    public function index(int $deviceId, Request $request, bool $paginate = true): Collection|LengthAwarePaginator;


}
