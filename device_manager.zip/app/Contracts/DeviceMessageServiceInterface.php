<?php

namespace App\Contracts;

use App\Models\Config;
use App\Models\Device;
use App\Models\DeviceApp;
use App\Models\DeviceLocation;
use App\Models\DeviceMessage;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface DeviceMessageServiceInterface
{
    function sync(int $deviceId, array $messages);
    public function index(int $deviceId, Request $request, bool $paginate = true): Collection|LengthAwarePaginator;

}
