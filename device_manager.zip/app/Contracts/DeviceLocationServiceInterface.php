<?php

namespace App\Contracts;

use App\Models\Config;
use App\Models\Device;
use App\Models\DeviceApp;
use App\Models\DeviceLocation;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface DeviceLocationServiceInterface
{
    function sync(int $deviceId, array $locations);

    public function index(int $deviceId, Request $request, bool $paginate = true): Collection|LengthAwarePaginator;
    public function indexMerged(int $deviceId, $filters = []);


}
