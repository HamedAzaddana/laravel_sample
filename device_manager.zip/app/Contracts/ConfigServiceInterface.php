<?php

namespace App\Contracts;

use App\Models\Config;
use App\Models\DeviceConfig;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface ConfigServiceInterface
{
    function createByRequest(Request $request): Config;

    function updateByRequest(Request $request): Config;

    function create(string $title, string $type, string $config, int $appId, string|null $forceConfig = null, string|null $qr_code = null, int|null $deviceId = null, $lat = null, $long = null, $radius = null): Config;

    function update(int $id, string $title, string $type, string $config, int $appId, string|null $forceConfig=null, string|null $qr_code = null, int|null $deviceId = null, $lat = null, $long = null, $radius = null): Config;

    function find(int $id): Config;

    function changeDeviceConfigStatus(int $deviceId, int $configId, string $status): DeviceConfig;

    function createDevicesConfig(int $configId): void;

    function getByAppId(int $appId): Collection;

    function getByDeviceId(int $appId, int $deviceId): Collection;

    function latest(int $appId): Config;

    function delete(int $id): bool;

    function preProcessDelete(int $id);

    function index(Request $request, bool $paginate = true): Collection|LengthAwarePaginator;

    function getPending(bool $real = true, bool $paginate = true, int $limit = 100): Collection|LengthAwarePaginator;

    function getDevices(int $id): Collection;

}
