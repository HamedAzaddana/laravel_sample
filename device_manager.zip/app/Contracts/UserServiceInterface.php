<?php

namespace App\Contracts;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use \Illuminate\Database\Eloquent\Collection;

interface UserServiceInterface
{
    function createByRequest(Request $request): User;

    function updateByRequest(Request $request): User;

    function create(string $name, string $username, string $password, array|null $roles = [], array|null $apps = []): User;

    function update(int $id, string $name, string $username, string $password, array|null $roles = [], array|null $apps = []): User;

    function find(int $id): User;

    function delete(int $id): bool;

    function findUserByUsername(string $username): User;

    function findUserByUsernamePassword(string $username, string $password): User;

    public function index(Request $request, bool $paginate = true): Collection|LengthAwarePaginator;
}
