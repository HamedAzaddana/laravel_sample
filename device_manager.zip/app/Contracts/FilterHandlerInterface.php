<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Builder;

interface FilterHandlerInterface
{
    public function handle(Builder $query, \Closure $next);

}