<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Builder;

interface FilterableInterface
{
    public function getFilters(): array;

}