<?php

use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard');
});
Route::get('/dd', [\App\Http\Controllers\Web\DeviceController::class, 'dd']);
Route::get('/dd2', [\App\Http\Controllers\Web\DeviceController::class, 'dd2']);
Route::prefix('authentication')->group(function () {
    Route::get('/', [\App\Http\Controllers\Web\AuthenticationController::class, 'authenticationPage'])->name('authentication.index');
    Route::post('/', [\App\Http\Controllers\Web\AuthenticationController::class, 'authentication'])->name('authentication');
    Route::any('/logout', [\App\Http\Controllers\Web\AuthenticationController::class, 'logout'])->name('authentication.logout');
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return Inertia::render('Dashboard');
    })->name('dashboard');
    Route::prefix('users')->group(function () {
        Route::get('/index', [\App\Http\Controllers\Web\UserController::class, 'index'])->name('users.index');
        Route::get('/add-all', [\App\Http\Controllers\Web\UserController::class, 'addAll'])->name('users.add-all');
        Route::get('/export', [\App\Http\Controllers\Web\UserController::class, 'export'])->name('users.export');
        Route::get('/create', [\App\Http\Controllers\Web\UserController::class, 'create'])->name('users.create');
        Route::post('/create', [\App\Http\Controllers\Web\UserController::class, 'store'])->name('users.store');
        Route::get('/{id}/edit', [\App\Http\Controllers\Web\UserController::class, 'edit'])->name('users.edit');
        Route::post('/{id}/edit', [\App\Http\Controllers\Web\UserController::class, 'update'])->name('users.update');
    });
    Route::prefix('configs')->group(function () {
        Route::get('/index', [\App\Http\Controllers\Web\ConfigController::class, 'index'])->name('configs.index');
        Route::get('/create', [\App\Http\Controllers\Web\ConfigController::class, 'create'])->name('configs.create');
        Route::post('/create', [\App\Http\Controllers\Web\ConfigController::class, 'store'])->name('configs.store');
        Route::get('/{id}/edit', [\App\Http\Controllers\Web\ConfigController::class, 'edit'])->name('configs.edit');
        Route::post('/{id}/edit', [\App\Http\Controllers\Web\ConfigController::class, 'update'])->name('configs.update');
        Route::get('/{id}/pending', [\App\Http\Controllers\Web\ConfigController::class, 'pending'])->name('configs.pending');
        Route::post('/{id}/pending', [\App\Http\Controllers\Web\ConfigController::class, 'sendPending'])->name('configs.pending.send');
        Route::any('/{id}/delete', [\App\Http\Controllers\Web\ConfigController::class, 'delete'])->name('configs.delete');
    });
    Route::prefix('devices')->group(function () {
        Route::get('/index', [\App\Http\Controllers\Web\DeviceController::class, 'index'])->name('devices.index');
//        Route::get('/create', [\App\Http\Controllers\Web\DeviceController::class, 'create'])->name('devices.create');
//        Route::post('/create', [\App\Http\Controllers\Web\DeviceController::class, 'store'])->name('devices.store');
        Route::get('/{id}/edit', [\App\Http\Controllers\Web\DeviceController::class, 'edit'])->name('devices.edit');
        Route::post('/{id}/edit', [\App\Http\Controllers\Web\DeviceController::class, 'update'])->name('devices.update');
        Route::any('/{id}/delete', [\App\Http\Controllers\Web\DeviceController::class, 'delete'])->name('devices.delete');
        Route::any('/{id}/config/wipe', [\App\Http\Controllers\Web\DeviceController::class, 'wipe_configs'])->name('devices.wipe_configs');
        Route::get('/{device_id}/apps/{id}/status/{status}', [\App\Http\Controllers\Web\DeviceController::class, 'appsChangeStatus'])->name('devices.apps.status');
        Route::get('/{device_id}/apps/index', [\App\Http\Controllers\Web\DeviceController::class, 'appsIndex'])->name('devices.apps.index');
        Route::get('/{device_id}/apps/{id}/delete', [\App\Http\Controllers\Web\DeviceController::class, 'appsDelete'])->name('devices.apps.delete');
        Route::get('/{device_id}/apps/create', [\App\Http\Controllers\Web\DeviceController::class, 'appsCreate'])->name('devices.apps.create');
        Route::post('/{device_id}/apps/create', [\App\Http\Controllers\Web\DeviceController::class, 'appsStore'])->name('devices.apps.store');
        Route::get('/{device_id}/locations/index', [\App\Http\Controllers\Web\DeviceController::class, 'locations'])->name('devices.locations.index');
        Route::get('/{device_id}/tracker/index', [\App\Http\Controllers\Web\DeviceController::class, 'tracker'])->name('devices.tracker.index');
        Route::get('/{device_id}/messages/index', [\App\Http\Controllers\Web\DeviceController::class, 'messages'])->name('devices.messages.index');
    });
});
if(env("APP_ENV")=="local" && file_exists(__DIR__."/test.php")){
    include_once __DIR__."/test.php";
}

