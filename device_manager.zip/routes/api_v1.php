<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::prefix('authentication')->group(function () {
    Route::middleware('auth:device')->get('/device', [\App\Http\Controllers\Api\AuthenticationController::class,'getAuthenticatedDevice']);
    Route::post('/', [\App\Http\Controllers\Api\AuthenticationController::class,'authentication']);
});
Route::prefix('devices')->middleware('auth:device')->group(function () {
    Route::get('/', [\App\Http\Controllers\Api\AuthenticationController::class,'getAuthenticatedDevice']);
    Route::get('/features', [\App\Http\Controllers\Api\DeviceController::class,'getFeatures']);
    Route::post('/sync/{type}', [\App\Http\Controllers\Api\DeviceController::class,'sync']);
});
Route::prefix('configs')->middleware('auth:device')->group(function () {
    Route::get('/{id}', [\App\Http\Controllers\Api\ConfigController::class,'find']);
});

